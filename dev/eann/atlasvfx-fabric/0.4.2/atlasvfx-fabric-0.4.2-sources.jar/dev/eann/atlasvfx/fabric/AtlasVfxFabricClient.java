package dev.eann.atlasvfx.fabric;

import dev.eann.atlasvfx.character.OverlayFeatureRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import dev.eann.atlasvfx.AtlasVfx;
import dev.eann.atlasvfx.WorldRenderHook;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_310;
import net.minecraft.class_922;

/**
 * Fabric's client entrypoint: adapts the one rendering hook Architectury does not bridge - see
 * {@link WorldRenderHook} - and starts the library.
 */
public final class AtlasVfxFabricClient implements ClientModInitializer {

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static OverlayFeatureRenderer overlays(class_922 renderer) {
        return new OverlayFeatureRenderer(renderer);
    }

    @Override
    public void onInitializeClient() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(context ->
                WorldRenderHook.AFTER_TRANSLUCENT.invoker().render(new WorldRenderHook.Context(
                        context.matrixStack(),
                        context.consumers(),
                        context.camera(),
                        context.tickCounter().method_60637(false))));
        WorldRenderEvents.LAST.register(context ->
                WorldRenderHook.AFTER_WEATHER.invoker().render(new WorldRenderHook.Context(
                        context.matrixStack(),
                        context.consumers() != null ? context.consumers()
                                : class_310.method_1551().method_22940().method_23000(),
                        context.camera(),
                        context.tickCounter().method_60637(false))));

        // Every living entity's renderer gets the overlay layer, through Fabric API's own hook.
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) ->
                helper.register(overlays(renderer)));

        AtlasVfx.initClient();
    }
}
