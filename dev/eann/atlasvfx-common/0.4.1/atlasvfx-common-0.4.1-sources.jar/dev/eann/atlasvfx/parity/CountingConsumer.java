package dev.eann.atlasvfx.parity;

import net.minecraft.class_4588;

/**
 * Passes every vertex on unchanged and counts them. Only ever handed out during a capture: it
 * hides the buffer behind it, so a renderer's fast path to that buffer (Sodium's, say) falls back
 * to the ordinary calls for the one frame recorded.
 */
final class CountingConsumer implements class_4588 {

    private final class_4588 delegate;
    private int vertices;

    CountingConsumer(class_4588 delegate) {
        this.delegate = delegate;
    }

    int vertices() {
        return vertices;
    }

    @Override
    public class_4588 method_22912(float x, float y, float z) {
        vertices++;
        delegate.method_22912(x, y, z);
        return this;
    }

    @Override
    public void method_23919(float x, float y, float z, int color, float u, float v, int overlay, int light,
                       float normalX, float normalY, float normalZ) {
        vertices++;
        delegate.method_23919(x, y, z, color, u, v, overlay, light, normalX, normalY, normalZ);
    }

    @Override
    public class_4588 method_1336(int red, int green, int blue, int alpha) {
        delegate.method_1336(red, green, blue, alpha);
        return this;
    }

    @Override
    public class_4588 method_22913(float u, float v) {
        delegate.method_22913(u, v);
        return this;
    }

    @Override
    public class_4588 method_60796(int u, int v) {
        delegate.method_60796(u, v);
        return this;
    }

    @Override
    public class_4588 method_22921(int u, int v) {
        delegate.method_22921(u, v);
        return this;
    }

    @Override
    public class_4588 method_22914(float x, float y, float z) {
        delegate.method_22914(x, y, z);
        return this;
    }
}
