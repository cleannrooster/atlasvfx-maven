package dev.eann.atlasvfx.model;

import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_630;

/**
 * A geometry file baked into the game's own model parts, ready to pose and draw.
 *
 * <p>One baked model is shared by every body it replaces, so posing it is done just before each
 * body is drawn, from rest: {@link #reset()} first, then whatever animation and following apply.
 * Render thread only.</p>
 *
 * @param root  holds the file's root bones; drawn as a whole body
 * @param bones every bone's part, by its name in the file
 */
public record BakedGeo(GeoModel source, class_630 root, Map<String, class_630> bones, GeoRig rig) {

    public BakedGeo {
        bones = Map.copyOf(bones);
    }

    public @Nullable class_630 bone(@Nullable String name) {
        return name == null ? null : bones.get(name);
    }

    /** Every bone back to the pose the file gives it. */
    public void reset() {
        root.method_32088().forEach(part -> {
            part.method_41923();
            part.field_3665 = true;
            part.field_38456 = false;
            part.field_37938 = 1.0f;
            part.field_37939 = 1.0f;
            part.field_37940 = 1.0f;
        });
    }
}
