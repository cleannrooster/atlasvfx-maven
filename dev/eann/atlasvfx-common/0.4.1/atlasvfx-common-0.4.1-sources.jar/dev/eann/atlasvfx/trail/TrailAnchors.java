package dev.eann.atlasvfx.trail;

import dev.eann.atlasvfx.FxAnchor;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

/** Anchors for recorded trails to follow. */
public final class TrailAnchors {

    private TrailAnchors() {
    }

    /**
     * A point held out from an entity's eyes along where it looks: a staff's tip, the point of a
     * held blade. Held while the entity is.
     *
     * @param drop    how far below the eyes the offset starts, in blocks
     * @param forward how far out along the look, in blocks
     * @param right   how far to the right of the look, in blocks
     */
    public static FxAnchor look(class_1297 entity, double drop, double forward, double right) {
        return new FxAnchor() {
            @Override
            public boolean held() {
                return !entity.method_31481();
            }

            @Override
            public boolean inView() {
                return false;
            }

            @Override
            @Nullable
            public class_243 position(float tickDelta) {
                if (entity.method_31481()) {
                    return null;
                }
                SweepFrame frame = SweepFrame.of(entity.method_5836(tickDelta).method_1023(0.0, drop, 0.0),
                        entity.method_5705(tickDelta), entity.method_5695(tickDelta));
                return frame.origin().method_1019(frame.forward().method_1021(forward)).method_1019(frame.right().method_1021(right));
            }
        };
    }

    /** The middle of an entity's body, held while the entity is: for something it trails. */
    public static FxAnchor body(class_1297 entity) {
        return new FxAnchor() {
            @Override
            public boolean held() {
                return !entity.method_31481();
            }

            @Override
            public boolean inView() {
                return false;
            }

            @Override
            @Nullable
            public class_243 position(float tickDelta) {
                return entity.method_31481() ? null
                        : entity.method_30950(tickDelta).method_1031(0.0, entity.method_17682() * 0.5, 0.0);
            }
        };
    }
}
