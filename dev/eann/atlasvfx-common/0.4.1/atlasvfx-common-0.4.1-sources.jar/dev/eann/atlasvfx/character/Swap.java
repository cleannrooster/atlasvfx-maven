package dev.eann.atlasvfx.character;

import net.minecraft.class_1921;
import net.minecraft.class_4588;

/**
 * What a substituted layer is drawn into instead, and in what colour.
 *
 * @param argbTint multiplies every vertex's colour, alpha included; {@link #NO_TINT} leaves the
 *                 colours as the model gave them, and is the only tint that keeps the buffer's own
 *                 fast path
 */
public record Swap(class_1921 layer, int argbTint) {

    public static final int NO_TINT = 0xFFFFFFFF;

    public static Swap of(class_1921 layer) {
        return new Swap(layer, NO_TINT);
    }

    public boolean tinted() {
        return argbTint != NO_TINT;
    }

    /** What to hand a renderer for this swap's buffer: the buffer, or the buffer tinted. */
    public class_4588 apply(class_4588 buffer) {
        return tinted() ? new TintingConsumer(buffer, argbTint) : buffer;
    }
}
