package dev.eann.atlasvfx.mixin;

import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** A phased layer's phases, for reading what kind of layer it is. */
@Mixin(class_1921.class_4687.class)
public interface MultiPhaseAccessor {

    @Accessor("phases")
    class_1921.class_4688 atlasvfx$phases();
}
