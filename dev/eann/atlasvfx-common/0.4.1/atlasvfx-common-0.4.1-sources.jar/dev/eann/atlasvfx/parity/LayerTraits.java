package dev.eann.atlasvfx.parity;

import dev.eann.atlasvfx.mixin.MultiPhaseAccessor;
import dev.eann.atlasvfx.mixin.MultiPhaseParametersAccessor;
import dev.eann.atlasvfx.mixin.RenderPhaseAccessor;
import dev.eann.atlasvfx.mixin.TextureBaseInvoker;
import dev.eann.atlasvfx.mixin.ToggleableAccessor;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

/**
 * What can be read off a render layer, as plain values: the classifier's whole input, so its
 * rules are tested without a game.
 *
 * <p>Read through accessor mixins, never by casting to the layer's own classes: those are opened
 * at compile time by this mod's widener, but at run time on NeoForge only as far as NeoForge's
 * own transformer opens them, and an interface the mixin adds is reachable everywhere.</p>
 *
 * @param phased       whether the layer is built from phases at all; a custom subclass is not,
 *                     and nothing past {@code mode} means anything for it
 * @param transparency the transparency phase's name, e.g. {@code translucent_transparency}
 * @param texturing    the texturing phase's name, e.g. {@code entity_glint_texturing}
 * @param target       the target phase's name, e.g. {@code outline_target}
 */
public record LayerTraits(String name, String format, String mode, boolean phased, boolean outline,
                          @Nullable class_2960 texture, String transparency, String texturing, String target,
                          boolean lightmap, boolean overlay, boolean translucent) {

    private static final Map<class_293, String> FORMATS = Map.ofEntries(
            Map.entry(class_290.field_1590, "block"),
            Map.entry(class_290.field_1580, "entity"),
            Map.entry(class_290.field_1584, "particle"),
            Map.entry(class_290.field_1592, "position"),
            Map.entry(class_290.field_1576, "position_color"),
            Map.entry(class_290.field_29337, "lines"),
            Map.entry(class_290.field_21468, "position_color_light"),
            Map.entry(class_290.field_1585, "position_tex"),
            Map.entry(class_290.field_1575, "position_tex_color"),
            Map.entry(class_290.field_20888, "text"),
            Map.entry(class_290.field_1586, "position_tex_light_color"),
            Map.entry(class_290.field_1577, "position_tex_color_normal"));

    /** The text format's name, which the classifier reads as "a name tag, not a body". */
    public static final String TEXT_FORMAT = "text";

    /** Reads a layer. Render thread. */
    public static LayerTraits of(class_1921 layer) {
        String name = ((RenderPhaseAccessor) layer).atlasvfx$name();
        String format = formatName(layer.method_23031());
        String mode = layer.method_23033().name().toLowerCase(java.util.Locale.ROOT);
        if (!(layer instanceof MultiPhaseAccessor multiPhase)) {
            return new LayerTraits(name, format, mode, false, layer.method_24295(), null, "", "", "", false, false,
                    layer.method_60894());
        }
        MultiPhaseParametersAccessor phases = (MultiPhaseParametersAccessor) (Object) multiPhase.atlasvfx$phases();
        class_4668.class_5939 texture = phases.atlasvfx$texture();
        class_2960 id = ((TextureBaseInvoker) texture).atlasvfx$id().orElse(null);
        return new LayerTraits(name, format, mode, true, layer.method_24295(), id,
                phaseName(phases.atlasvfx$transparency()), phaseName(phases.atlasvfx$texturing()),
                phaseName(phases.atlasvfx$target()),
                ((ToggleableAccessor) phases.atlasvfx$lightmap()).atlasvfx$enabled(),
                ((ToggleableAccessor) phases.atlasvfx$overlay()).atlasvfx$enabled(),
                layer.method_60894());
    }

    static String formatName(class_293 format) {
        String known = FORMATS.get(format);
        return known != null ? known : format.toString();
    }

    private static String phaseName(class_4668 phase) {
        return ((RenderPhaseAccessor) phase).atlasvfx$name();
    }
}
