package dev.eann.atlasvfx.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

/** The texture a phase binds: empty for none, or for several at once. */
@Mixin(class_4668.class_5939.class)
public interface TextureBaseInvoker {

    @Invoker("getId")
    Optional<class_2960> atlasvfx$id();
}
