package dev.eann.atlasvfx.appearance;

import dev.eann.atlasvfx.AtlasVfxCommon;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** What client and server say about appearances. Safe on a dedicated server. */
public final class AppearancePayloads {

    private AppearancePayloads() {
    }

    /** "I want to be seen as this; empty for my own skin." Client to server. */
    public record Choose(Optional<class_2960> appearance) implements class_8710 {

        public static final class_8710.class_9154<Choose> ID =
                new class_8710.class_9154<>(class_2960.method_60655(AtlasVfxCommon.MOD_ID, "choose_appearance"));

        public static final class_9139<class_9129, Choose> CODEC = class_9139.method_56438(Choose::write, Choose::read);

        public static Choose of(@Nullable class_2960 appearance) {
            return new Choose(Optional.ofNullable(appearance));
        }

        private void write(class_9129 buffer) {
            buffer.method_52964(appearance.isPresent());
            appearance.ifPresent(buffer::method_10812);
        }

        private static Choose read(class_9129 buffer) {
            return new Choose(buffer.readBoolean() ? Optional.of(buffer.method_10810()) : Optional.empty());
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /**
     * "These appearances are locked, by these advancements, and you have unlocked these." Server to
     * client, to the player it is about: as they join, as they earn one, and as data reloads.
     */
    public record Unlocks(Map<class_2960, class_2960> requirements, Set<class_2960> unlocked)
            implements class_8710 {

        public static final class_8710.class_9154<Unlocks> ID =
                new class_8710.class_9154<>(class_2960.method_60655(AtlasVfxCommon.MOD_ID, "appearance_unlocks"));

        public static final class_9139<class_9129, Unlocks> CODEC = class_9139.method_56438(Unlocks::write, Unlocks::read);

        public Unlocks {
            requirements = Map.copyOf(requirements);
            unlocked = Set.copyOf(unlocked);
        }

        private void write(class_9129 buffer) {
            buffer.method_10804(requirements.size());
            requirements.forEach((appearance, advancement) -> {
                buffer.method_10812(appearance);
                buffer.method_10812(advancement);
            });
            buffer.method_10804(unlocked.size());
            unlocked.forEach(buffer::method_10812);
        }

        private static Unlocks read(class_9129 buffer) {
            int count = buffer.method_10816();
            Map<class_2960, class_2960> requirements = new LinkedHashMap<>();
            for (int i = 0; i < count; i++) {
                requirements.put(buffer.method_10810(), buffer.method_10810());
            }
            int unlockedCount = buffer.method_10816();
            Set<class_2960> unlocked = new HashSet<>();
            for (int i = 0; i < unlockedCount; i++) {
                unlocked.add(buffer.method_10810());
            }
            return new Unlocks(requirements, unlocked);
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /** "I have been asked to choose, and closed the screen." Client to server. */
    public record Prompted() implements class_8710 {

        public static final class_8710.class_9154<Prompted> ID =
                new class_8710.class_9154<>(class_2960.method_60655(AtlasVfxCommon.MOD_ID, "appearance_prompted"));

        public static final class_9139<class_9129, Prompted> CODEC = class_9139.method_56431(new Prompted());

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }

    /**
     * "Appearances are on or off here, and these players chose these." Server to client: everyone's,
     * replacing what the client knew, as it joins; one player's, as they choose or join.
     *
     * @param full    whether it replaces everything the client knew
     * @param prompt  whether this client should ask its player to choose, as soon as it may: only ever
     *                on a full sync, to a player who has never been asked here
     * @param choices by player; empty for a player back in their own skin
     */
    public record Sync(boolean enabled, boolean full, boolean prompt, Map<UUID, Optional<class_2960>> choices)
            implements class_8710 {

        public static final class_8710.class_9154<Sync> ID =
                new class_8710.class_9154<>(class_2960.method_60655(AtlasVfxCommon.MOD_ID, "appearances"));

        public static final class_9139<class_9129, Sync> CODEC = class_9139.method_56438(Sync::write, Sync::read);

        public Sync {
            choices = Map.copyOf(choices);
        }

        private void write(class_9129 buffer) {
            buffer.method_52964(enabled);
            buffer.method_52964(full);
            buffer.method_52964(prompt);
            buffer.method_10804(choices.size());
            for (Map.Entry<UUID, Optional<class_2960>> entry : choices.entrySet()) {
                buffer.method_10797(entry.getKey());
                buffer.method_52964(entry.getValue().isPresent());
                entry.getValue().ifPresent(buffer::method_10812);
            }
        }

        private static Sync read(class_9129 buffer) {
            boolean enabled = buffer.readBoolean();
            boolean full = buffer.readBoolean();
            boolean prompt = buffer.readBoolean();
            int count = buffer.method_10816();
            Map<UUID, Optional<class_2960>> choices = new LinkedHashMap<>();
            for (int i = 0; i < count; i++) {
                UUID player = buffer.method_10790();
                choices.put(player, buffer.readBoolean() ? Optional.of(buffer.method_10810()) : Optional.empty());
            }
            return new Sync(enabled, full, prompt, choices);
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }
}
