package dev.eann.atlasvfx.cue;

import dev.eann.atlasvfx.AtlasVfxCommon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** "Play cue {@code cue} with these arguments." Server to client. */
public record FxCuePayload(class_2960 cue, FxCueArgs args) implements class_8710 {

    public static final class_8710.class_9154<FxCuePayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(AtlasVfxCommon.MOD_ID, "cue"));

    public static final class_9139<class_9129, FxCuePayload> CODEC =
            class_9139.method_56438(FxCuePayload::write, FxCuePayload::read);

    private void write(class_9129 buffer) {
        buffer.method_10812(cue);
        args.write(buffer);
    }

    private static FxCuePayload read(class_9129 buffer) {
        return new FxCuePayload(buffer.method_10810(), FxCueArgs.read(buffer));
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
