package dev.eann.atlasvfx.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import dev.eann.atlasvfx.character.CharacterEffects;
import dev.eann.atlasvfx.parity.LayerSource;
import dev.eann.atlasvfx.model.Replacements;
import dev.eann.atlasvfx.parity.ProviderSeam;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Names the feature renderer behind each layer asked for while the provider seam has the entity
 * wrapped - for a capture to attribute it, and for a look to tell which body part it is for - and
 * draws a replacement model where the vanilla one was drawn.
 */
@Mixin(class_922.class)
abstract class LivingEntityRendererMixin {

    @WrapOperation(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/Entity;FFFFFF)V"))
    private void atlasvfx$attributeFeature(class_3887<?, ?> feature, class_4587 matrices,
                                           class_4597 provider, int light, class_1297 entity,
                                           float limbAngle, float limbDistance, float tickDelta,
                                           float animationProgress, float headYaw, float headPitch,
                                           Operation<Void> original) {
        if (!ProviderSeam.scoped()) {
            original.call(feature, matrices, provider, light, entity, limbAngle, limbDistance, tickDelta,
                    animationProgress, headYaw, headPitch);
            return;
        }
        if (Replacements.hidesFeature(entity, feature)) {
            // Armour, a cape, another mod's layer - a part the replacement stands in for is not drawn
            // at all, rather than built for nothing into a layer nobody sees.
            return;
        }
        ProviderSeam.enter(new LayerSource.Feature(feature.getClass()));
        try {
            original.call(feature, matrices, provider, light, entity, limbAngle, limbDistance, tickDelta,
                    animationProgress, headYaw, headPitch);
        } finally {
            ProviderSeam.exit();
        }
    }

    /**
     * Right after the vanilla model is drawn - into hidden layers, if the body is replaced - draws
     * the replacement in the same pose matrices, light, hurt tint and colour.
     */
    @WrapOperation(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"))
    private void atlasvfx$drawReplacement(class_583<?> model, class_4587 matrices, class_4588 buffer, int light,
                                          int overlay, int color, Operation<Void> original,
                                          @Local(argsOnly = true) class_1309 entity,
                                          @Local(argsOnly = true) class_4597 consumers,
                                          @Local(argsOnly = true, ordinal = 1) float tickDelta) {
        original.call(model, matrices, buffer, light, overlay, color);
        if (CharacterEffects.any()) {
            Replacements.drawBody(entity, model, matrices, consumers, light, overlay, color, tickDelta);
        }
    }
}
