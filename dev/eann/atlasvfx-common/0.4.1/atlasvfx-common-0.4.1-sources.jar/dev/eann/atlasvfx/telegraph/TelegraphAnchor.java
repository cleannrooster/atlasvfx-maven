package dev.eann.atlasvfx.telegraph;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

/**
 * Something a telegraph follows until it locks: a boss turning to face its target before the
 * cleave commits.
 */
public interface TelegraphAnchor {

    /** Where the area's origin is this frame, or null when it cannot be found. */
    @Nullable
    class_243 position(float tickDelta);

    /** Which way the area faces this frame, as the game turns: 0 is south. */
    float yaw(float tickDelta);

    /** An entity's feet, facing where its body faces. */
    static TelegraphAnchor feet(class_1297 entity) {
        return new TelegraphAnchor() {
            @Override
            @Nullable
            public class_243 position(float tickDelta) {
                return entity.method_31481() ? null : entity.method_30950(tickDelta);
            }

            @Override
            public float yaw(float tickDelta) {
                return entity.method_5705(tickDelta);
            }
        };
    }
}
