package dev.eann.atlasvfx;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_757;
import org.jetbrains.annotations.Nullable;

/**
 * The layer every pass draws into, in the world and on the screen.
 *
 * <p>Most of them the game does not offer. Light has to be added on top of what is behind it,
 * weighted by its own transparency, and without hiding anything drawn after it. The game's
 * additive layers either ignore transparency - so a soft picture comes out as a square - or
 * write depth, so a glow hides the sparks behind it. The world's light layers do neither: they
 * are tested against depth, so a wall or a body in front still hides them, but never write it.</p>
 *
 * <p>The screen's layers draw over whatever the screen has drawn so far and never write depth,
 * so nothing drawn after them is hidden. They turn off culling, so a picture shows whichever way
 * round its corners went.</p>
 *
 * <p>Every layer is built the way the game builds its own - {@code RenderLayer.of} with its
 * standard phases - rather than as a layer that sets the state by hand. That matters to mods that
 * read layers rather than run them: a shader pack under Iris picks its program and its draw order
 * from these phases, and a layer whose state it cannot see is treated as opaque and drawn first,
 * underneath what it should sit on. {@code of} is closed in the game's own code; NeoForge's access
 * transformer opens it, and on Fabric Fabric API's transitive access wideners do, with this mod's
 * own widener declaring it too. Each layer is built once, the first time it is asked for.</p>
 *
 * <p>Pictures are bound without changing the atlas's filtering, as the game's particles leave it:
 * a texture phase that set it would change it for everything else drawn from the same atlas.</p>
 */
public final class FxLayers extends class_1921 {

    private static final int ATLASES = AtlasRef.values().size();
    private static final int BUFFER_SIZE = 4096;

    private static final class_5942 COLOUR = new class_5942(class_757::method_34540);
    private static final class_5942 PARTICLE = new class_5942(class_757::method_34546);
    private static final class_5942 TEXTURE_COLOUR = new class_5942(class_757::method_34543);

    private static final class_1921 WORLD_GLOW = method_24049("atlasvfx_world_glow", class_290.field_1576,
            class_293.class_5596.field_27382, BUFFER_SIZE, false, false,
            class_4688.method_23598()
                    .method_34578(COLOUR)
                    // Added, but only as much as the pixel is there: a soft edge stays soft.
                    .method_23615(field_21367)
                    .method_23604(field_21348)
                    .method_23616(field_21350)
                    .method_23603(field_21345)
                    .method_23617(false));

    private static final class_1921 SCREEN_GLOW = method_24049("atlasvfx_screen_glow", class_290.field_1576,
            class_293.class_5596.field_27382, BUFFER_SIZE, false, false,
            class_4688.method_23598()
                    .method_34578(COLOUR)
                    .method_23615(field_21367)
                    .method_23604(field_21346)
                    .method_23616(field_21350)
                    .method_23603(field_21345)
                    .method_23617(false));

    private static final class_1921[] WORLD_EMISSIVE = new class_1921[ATLASES];
    private static final class_1921[] SCREEN_EMISSIVE = new class_1921[ATLASES];
    private static final class_1921[] SCREEN_LIT = new class_1921[ATLASES];

    private FxLayers() {
        // Never made: extending RenderLayer is only for its phases.
        super("atlasvfx_layers", class_290.field_1592, class_293.class_5596.field_27382, 0, false, false, () -> {
        }, () -> {
        });
    }

    /**
     * The layer a pass draws into in this space; null for one that cannot be drawn there - the
     * End's starfield is a thing of the world.
     */
    @Nullable
    public static class_1921 of(FxSpace space, FxPass pass) {
        AtlasRef atlas = pass.atlas();
        return switch (pass.kind()) {
            case GLOW -> space == FxSpace.WORLD ? WORLD_GLOW : SCREEN_GLOW;
            case RIFT -> space == FxSpace.WORLD ? class_1921.method_23574() : null;
            case LIT -> space == FxSpace.WORLD
                    ? class_1921.method_23580(atlas.texture())
                    : screenLit(atlas);
            case EMISSIVE -> space == FxSpace.WORLD ? emissive(atlas) : screenEmissive(atlas);
        };
    }

    /** A picture from this atlas as light, out in the world. */
    public static synchronized class_1921 emissive(AtlasRef atlas) {
        class_1921 layer = WORLD_EMISSIVE[atlas.index()];
        if (layer == null) {
            layer = method_24049("atlasvfx_world_emissive_" + atlas.name(), class_290.field_1584,
                    class_293.class_5596.field_27382, BUFFER_SIZE, false, false,
                    class_4688.method_23598()
                            // The particle program: the one the game draws its own sparks with, so
                            // fog and the lightmap behave the way they do on those.
                            .method_34578(PARTICLE)
                            .method_34577(atlasTexture(atlas))
                            .method_23615(field_21367)
                            .method_23604(field_21348)
                            .method_23616(field_21350)
                            .method_23603(field_21345)
                            .method_23608(field_21383)
                            .method_23617(false));
            WORLD_EMISSIVE[atlas.index()] = layer;
        }
        return layer;
    }

    /** Untextured light, out in the world. */
    public static class_1921 glow() {
        return WORLD_GLOW;
    }

    private static synchronized class_1921 screenEmissive(AtlasRef atlas) {
        class_1921 layer = SCREEN_EMISSIVE[atlas.index()];
        if (layer == null) {
            layer = screenPicture("atlasvfx_screen_emissive_", atlas, field_21367);
            SCREEN_EMISSIVE[atlas.index()] = layer;
        }
        return layer;
    }

    private static synchronized class_1921 screenLit(AtlasRef atlas) {
        class_1921 layer = SCREEN_LIT[atlas.index()];
        if (layer == null) {
            // Laid over as a solid picture rather than added as light.
            layer = screenPicture("atlasvfx_screen_lit_", atlas, field_21370);
            SCREEN_LIT[atlas.index()] = layer;
        }
        return layer;
    }

    private static class_1921 screenPicture(String name, AtlasRef atlas, class_4685 transparency) {
        return method_24049(name + atlas.name(), class_290.field_1575, class_293.class_5596.field_27382,
                BUFFER_SIZE, false, false,
                class_4688.method_23598()
                        .method_34578(TEXTURE_COLOUR)
                        .method_34577(atlasTexture(atlas))
                        .method_23615(transparency)
                        .method_23604(field_21346)
                        .method_23616(field_21350)
                        .method_23603(field_21345)
                        .method_23617(false));
    }

    /** Binds an atlas without touching its filtering. */
    private static class_5939 atlasTexture(AtlasRef atlas) {
        return new class_5939(() -> RenderSystem.setShaderTexture(0, atlas.texture()), () -> {
        });
    }
}
