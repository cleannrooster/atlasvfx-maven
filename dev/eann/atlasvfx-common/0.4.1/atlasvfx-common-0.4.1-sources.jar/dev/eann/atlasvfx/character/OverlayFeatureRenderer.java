package dev.eann.atlasvfx.character;

import dev.eann.atlasvfx.model.Replacements;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;

/**
 * The feature layer every living entity's renderer is given, through each loader's own hook for
 * adding one: draws the body's overlays over its model, posed exactly as the renderer just drew
 * it - by whatever animation mod posed it.
 *
 * <p>Added once per renderer, last of the features added at that point, so armour drawn before it
 * hides the body under it the way it would hide the skin.</p>
 */
public final class OverlayFeatureRenderer<T extends class_1309, M extends class_583<T>>
        extends class_3887<T, M> {

    public OverlayFeatureRenderer(class_3883<T, M> context) {
        super(context);
    }

    @Override
    public void render(class_4587 matrices, class_4597 consumers, int light, T entity, float limbAngle,
                       float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        if (!CharacterEffects.any() || !CharacterEffects.drawable(entity)) {
            return;
        }
        List<OverlayPass> passes = CharacterEffects.overlaysOf(entity);
        if (passes.isEmpty()) {
            return;
        }
        Replacements.Active replaced = Replacements.active(entity);
        if (replaced != null) {
            // Over the replacement, as the replacement left its bones this frame.
            CharacterEffects.drawPart(passes, replaced.model().root(), replaced.replacement().texture(), matrices,
                    consumers, light, animationProgress);
            return;
        }
        CharacterEffects.drawModel(passes, method_17165(), method_23194(entity), matrices, consumers, light,
                animationProgress);
    }
}
