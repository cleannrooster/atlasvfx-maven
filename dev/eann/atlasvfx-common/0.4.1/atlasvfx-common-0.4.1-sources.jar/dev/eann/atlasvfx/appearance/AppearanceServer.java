package dev.eann.atlasvfx.appearance;

import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.event.events.common.PlayerEvent;
import dev.architectury.networking.NetworkManager;
import dev.architectury.platform.Platform;
import dev.architectury.registry.ReloadListenerRegistry;
import dev.architectury.utils.Env;
import dev.eann.atlasvfx.AtlasVfxConfig;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_4013;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Keeps which appearance each player chose, with the world, and tells every client. Safe on a
 * dedicated server: it names nothing that draws, and what an appearance looks like is the client's
 * business - the server keeps only its id.
 *
 * <p>While the setting is off, choices are refused and nobody is shown one; choices made before are
 * kept, for when it is turned on again.</p>
 *
 * <p>An appearance a data pack locks behind an advancement - see {@link AppearanceUnlocks} - may only
 * be chosen by a player who has done it: the server refuses it otherwise, and takes it off a player
 * who has lost the advancement since.</p>
 *
 * <p>A player joining for the first time is told to ask them to choose, if the setting says to; once
 * they close the screen or choose, they are never asked again here.</p>
 */
public final class AppearanceServer {

    private static final String SAVE = "atlasvfx_appearances";
    private static final class_18.class_8645<Saved> TYPE = new class_18.class_8645<>(Saved::new, Saved::read, null);

    /** Each player's choice, by UUID, and who has been asked to choose, kept in the overworld's data. */
    static final class Saved extends class_18 {
        final Map<UUID, class_2960> choices = new HashMap<>();
        final Set<UUID> prompted = new HashSet<>();

        static Saved read(class_2487 nbt, class_7225.class_7874 lookup) {
            Saved saved = new Saved();
            class_2487 choices = nbt.method_10562("choices");
            for (String key : choices.method_10541()) {
                try {
                    class_2960 id = class_2960.method_12829(choices.method_10558(key));
                    if (id != null) {
                        saved.choices.put(UUID.fromString(key), id);
                    }
                } catch (IllegalArgumentException ignored) {
                    // Not a UUID: skip it.
                }
            }
            class_2499 prompted = nbt.method_10554("prompted", class_2520.field_33258);
            for (int i = 0; i < prompted.size(); i++) {
                try {
                    saved.prompted.add(UUID.fromString(prompted.method_10608(i)));
                } catch (IllegalArgumentException ignored) {
                    // Not a UUID: skip it.
                }
            }
            return saved;
        }

        @Override
        public class_2487 method_75(class_2487 nbt, class_7225.class_7874 lookup) {
            class_2487 out = new class_2487();
            choices.forEach((player, id) -> out.method_10582(player.toString(), id.toString()));
            nbt.method_10566("choices", out);
            class_2499 prompted = new class_2499();
            this.prompted.forEach(player -> prompted.add(class_2519.method_23256(player.toString())));
            nbt.method_10566("prompted", prompted);
            return nbt;
        }
    }

    private AppearanceServer() {
    }

    /** Both sides, at mod construction. */
    public static void init() {
        if (Platform.getEnvironment() == Env.SERVER) {
            NetworkManager.registerS2CPayloadType(AppearancePayloads.Sync.ID, AppearancePayloads.Sync.CODEC);
            NetworkManager.registerS2CPayloadType(AppearancePayloads.Unlocks.ID, AppearancePayloads.Unlocks.CODEC);
        }
        LifecycleEvent.SERVER_STARTED.register(started -> server = started);
        LifecycleEvent.SERVER_STOPPED.register(stopped -> server = null);
        // What locks what is data, read on start and on /reload; a reload tells everyone again.
        ReloadListenerRegistry.register(class_3264.field_14190, (class_4013) manager -> {
            AppearanceUnlocks.reload(manager);
            MinecraftServer running = server;
            if (running != null) {
                running.execute(() -> running.method_3760().method_14571().forEach(player -> {
                    sendUnlocks(player);
                    dropIfLocked(player);
                }));
            }
        });
        // Earning an advancement may unlock something: say so at once.
        PlayerEvent.PLAYER_ADVANCEMENT.register((player, advancement) -> {
            if (AppearanceUnlocks.unlocksAnything(advancement.comp_1919())) {
                sendUnlocks(player);
            }
        });
        NetworkManager.registerReceiver(NetworkManager.Side.C2S, AppearancePayloads.Choose.ID,
                AppearancePayloads.Choose.CODEC, (payload, context) -> context.queue(() -> {
                    if (context.getPlayer() instanceof class_3222 player) {
                        choose(player, payload.appearance().orElse(null));
                    }
                }));
        NetworkManager.registerReceiver(NetworkManager.Side.C2S, AppearancePayloads.Prompted.ID,
                AppearancePayloads.Prompted.CODEC, (payload, context) -> context.queue(() -> {
                    if (context.getPlayer() instanceof class_3222 player && player.method_5682() != null) {
                        Saved saved = saved(player.method_5682());
                        if (saved.prompted.add(player.method_5667())) {
                            saved.method_80();
                        }
                    }
                }));
        PlayerEvent.PLAYER_JOIN.register(AppearanceServer::joined);
    }

    private static volatile @Nullable MinecraftServer server;

    private static Saved saved(MinecraftServer server) {
        return server.method_30002().method_17983().method_17924(TYPE, SAVE);
    }

    /** Everyone's choices to the player joining, and theirs to everyone else. */
    private static void joined(class_3222 player) {
        MinecraftServer server = player.method_5682();
        if (server == null) {
            return;
        }
        boolean enabled = AtlasVfxConfig.appearancesEnabled();
        if (enabled) {
            sendUnlocks(player);
            // Earned once and since taken away - by a command, a data pack change - it comes off.
            dropIfLocked(player);
        }
        Map<UUID, Optional<class_2960>> all = new LinkedHashMap<>();
        if (enabled) {
            saved(server).choices.forEach((uuid, id) -> all.put(uuid, Optional.of(id)));
        }
        Saved saved = saved(server);
        boolean prompt = AtlasVfxConfig.promptOnFirstJoin() && !saved.prompted.contains(player.method_5667())
                && !saved.choices.containsKey(player.method_5667());
        send(player, new AppearancePayloads.Sync(enabled, true, prompt, all));
        class_2960 own = enabled ? saved(server).choices.get(player.method_5667()) : null;
        if (own != null) {
            broadcast(server, player, Optional.of(own));
        }
    }

    /** A player's choice: kept, and shown to everyone - or refused, while the setting is off. */
    static void choose(class_3222 player, @Nullable class_2960 appearance) {
        MinecraftServer server = player.method_5682();
        if (server == null) {
            return;
        }
        if (!AtlasVfxConfig.appearancesEnabled()) {
            // Puts the client straight: nothing is shown here.
            send(player, new AppearancePayloads.Sync(false, true, false, Map.of()));
            return;
        }
        if (appearance != null && !AppearanceUnlocks.unlocked(player, appearance)) {
            // Not earned: refused, and the client told again what it has unlocked.
            sendUnlocks(player);
            return;
        }
        Saved saved = saved(server);
        if (appearance == null) {
            saved.choices.remove(player.method_5667());
        } else {
            saved.choices.put(player.method_5667(), appearance);
        }
        // Having chosen, there is nothing left to ask.
        saved.prompted.add(player.method_5667());
        saved.method_80();
        broadcast(server, player, Optional.ofNullable(appearance));
    }

    /** Tells {@code player} what is locked and what they have unlocked. */
    static void sendUnlocks(class_3222 player) {
        if (!AtlasVfxConfig.appearancesEnabled()
                || !NetworkManager.canPlayerReceive(player, AppearancePayloads.Unlocks.ID)) {
            return;
        }
        NetworkManager.sendToPlayer(player, new AppearancePayloads.Unlocks(AppearanceUnlocks.requirements(),
                AppearanceUnlocks.unlockedBy(player)));
    }

    /** Takes off what {@code player} wears if it is locked to them now, and tells everyone. */
    private static void dropIfLocked(class_3222 player) {
        MinecraftServer running = player.method_5682();
        if (running == null || !AtlasVfxConfig.appearancesEnabled()) {
            return;
        }
        Saved saved = saved(running);
        class_2960 wearing = saved.choices.get(player.method_5667());
        if (wearing != null && !AppearanceUnlocks.unlocked(player, wearing)) {
            saved.choices.remove(player.method_5667());
            saved.method_80();
            broadcast(running, player, Optional.empty());
        }
    }

    private static void broadcast(MinecraftServer server, class_3222 chooser, Optional<class_2960> appearance) {
        AppearancePayloads.Sync sync = new AppearancePayloads.Sync(true, false, false,
                Map.of(chooser.method_5667(), appearance));
        for (class_3222 player : server.method_3760().method_14571()) {
            send(player, sync);
        }
    }

    private static void send(class_3222 player, AppearancePayloads.Sync sync) {
        if (NetworkManager.canPlayerReceive(player, AppearancePayloads.Sync.ID)) {
            NetworkManager.sendToPlayer(player, sync);
        }
    }
}
