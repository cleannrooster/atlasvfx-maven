package dev.eann.atlasvfx;

import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_638;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.jetbrains.annotations.Nullable;

/** The light a piece of an effect is drawn in. */
public final class FxLight {

    /** As bright as anything gets: for light, and for pictures that light themselves. */
    public static final int FULL_BRIGHT = class_765.field_32767;

    private FxLight() {
    }

    /** The world's light at a point; full bright where there is no world to ask. */
    public static int at(@Nullable class_638 world, class_243 at) {
        return world == null ? FULL_BRIGHT : class_761.method_23794(world, class_2338.method_49638(at));
    }

    /**
     * The same light with its block light raised to at least {@code minBlock}, 0 to 15: something
     * lit by the world that should dim in the dark without vanishing.
     */
    public static int withMinBlock(int packed, int minBlock) {
        int floor = Math.max(0, Math.min(15, minBlock));
        int block = Math.max(class_765.method_24186(packed), floor);
        return class_765.method_23687(block, class_765.method_24187(packed));
    }
}
