package dev.eann.atlasvfx.cue;

import dev.architectury.networking.NetworkManager;
import dev.eann.atlasvfx.telegraph.TelegraphArea;
import dev.eann.atlasvfx.telegraph.TelegraphTiming;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

/**
 * The server's side of cues: tells nearby players' clients to draw a cue or a telegraph. Safe on a
 * dedicated server - it touches only the telegraph geometry, never anything that draws.
 *
 * <p>A player whose client does not have AtlasVFX is simply not sent anything.</p>
 */
public final class FxEmitter {

    /** Players further than this from a cue never hear of it, in blocks. */
    public static final double RANGE = 96.0;
    /** How long a telegraph lingers after it lands, unless asked otherwise. */
    public static final int TELEGRAPH_FADE_TICKS = 8;

    private FxEmitter() {
    }

    /** Draws {@code cue} for every player within {@link #RANGE} of where it is. */
    public static void emit(class_3218 world, class_2960 cue, FxCueArgs args) {
        send(world, args.at(), RANGE, new FxCuePayload(cue, args));
    }

    /** Draws {@code cue} for every player within {@code range} of where it is. */
    public static void emit(class_3218 world, class_2960 cue, FxCueArgs args, double range) {
        send(world, args.at(), range, new FxCuePayload(cue, args));
    }

    /**
     * Warns of {@code area} - the area the server will hit-test, already placed and turned - landing
     * {@code windupTicks} from now, in the look named {@code style}.
     */
    public static void telegraph(class_3218 world, TelegraphArea area, int windupTicks, class_2960 style) {
        telegraph(world, area, TelegraphTiming.starting(world.method_8510(), windupTicks, TELEGRAPH_FADE_TICKS), style, 0);
    }

    /**
     * Warns of {@code area} on its own timing, in the look named {@code style}, or in {@code colour}
     * ({@code 0xRRGGBB}) if that is not 0.
     */
    public static void telegraph(class_3218 world, TelegraphArea area, TelegraphTiming timing, class_2960 style,
                                 int colour) {
        send(world, area.origin(), RANGE, new TelegraphPayload(area, timing, style, colour));
    }

    private static void send(class_3218 world, class_243 at, double range, class_8710 payload) {
        double rangeSq = range * range;
        for (class_3222 player : world.method_18456()) {
            if (player.method_5707(at) <= rangeSq && NetworkManager.canPlayerReceive(player, payload.method_56479())) {
                NetworkManager.sendToPlayer(player, payload);
            }
        }
    }
}
