package dev.eann.atlasvfx.mixin;

import net.minecraft.class_1921;
import net.minecraft.class_4668;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** The phases the classifier reads: what is drawn, how it blends, and where to. */
@Mixin(class_1921.class_4688.class)
public interface MultiPhaseParametersAccessor {

    @Accessor("texture")
    class_4668.class_5939 atlasvfx$texture();

    @Accessor("transparency")
    class_4668.class_4685 atlasvfx$transparency();

    @Accessor("texturing")
    class_4668.class_4684 atlasvfx$texturing();

    @Accessor("target")
    class_4668.class_4678 atlasvfx$target();

    @Accessor("lightmap")
    class_4668.class_4676 atlasvfx$lightmap();

    @Accessor("overlay")
    class_4668.class_4679 atlasvfx$overlay();
}
