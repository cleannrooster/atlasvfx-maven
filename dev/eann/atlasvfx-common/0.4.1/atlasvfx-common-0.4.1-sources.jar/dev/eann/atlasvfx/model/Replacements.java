package dev.eann.atlasvfx.model;

import dev.eann.atlasvfx.character.BodyParts;
import dev.eann.atlasvfx.character.CharacterEffects;
import dev.eann.atlasvfx.parity.LayerSource;
import dev.eann.atlasvfx.parity.ProviderSeam;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5603;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_630;

/**
 * Draws replacement models where the bodies they replace are drawn: posed and drawn right after
 * the vanilla model's own draw - which drew nothing, its layers hidden by the provider seam - in
 * the same matrices, light, hurt tint and colour; and over the first-person arm.
 *
 * <p>Called from this mod's mixins and overlay layer, on the render thread.</p>
 */
@ApiStatus.Internal
public final class Replacements {

    /** A body's replacement, with its model loaded. */
    public record Active(ModelReplacement replacement, BakedGeo model) {
    }

    /** What a replaced first-person arm was drawn as, for overlays to be drawn over. */
    public record PosedArm(class_630 bone, class_2960 texture) {
    }

    // One state per body per replacement: a screen previewing several on the same player must not
    // have them restart each other's clips.
    private static final Map<class_1297, Map<ModelReplacement, GeoAnimationState>> STATES = new WeakHashMap<>();

    private Replacements() {
    }

    static void clearStates() {
        STATES.clear();
    }

    /** {@code entity}'s replacement now, if it has one and its model loads. */
    public static @Nullable Active active(class_1297 entity) {
        if (!CharacterEffects.any()) {
            return null;
        }
        ModelReplacement replacement = CharacterEffects.of(entity).replacement();
        if (replacement == null) {
            return null;
        }
        BakedGeo model = GeoAssets.model(replacement.geo());
        return model == null ? null : new Active(replacement, model);
    }

    /**
     * Whether {@code feature} - armour, a cape, another mod's layer - draws a part {@code entity}'s
     * replacement stands in for, so is left out entirely.
     */
    public static boolean hidesFeature(class_1297 entity, Object feature) {
        Active active = active(entity);
        return active != null && active.replacement().hides(BodyParts.of(feature.getClass()));
    }

    /** After the vanilla model's draw: poses and draws {@code entity}'s replacement, if it has one. */
    public static void drawBody(class_1309 entity, class_583<?> vanilla, class_4587 matrices,
                                class_4597 consumers, int light, int overlay, int color, float tickDelta) {
        Active active = active(entity);
        if (active == null) {
            return;
        }
        pose(entity, active, vanilla, tickDelta);
        class_1921 layer = layer(active.replacement().texture(), color);
        draw(() -> active.model().root().method_22699(matrices, consumers.getBuffer(layer), light, overlay, color));
    }

    /**
     * After a first-person arm's draw: draws the replacement's arm bone in its place, posed as the
     * vanilla arm was; null if the body has no replacement or its model no arm on that side.
     */
    public static @Nullable PosedArm drawArm(class_1309 player, class_1306 side, class_591<?> vanilla,
                                             class_4587 matrices, class_4597 consumers, int light) {
        Active active = active(player);
        if (active == null) {
            return null;
        }
        BakedGeo model = active.model();
        String name = side == class_1306.field_6183 ? model.rig().rightArm() : model.rig().leftArm();
        class_630 bone = model.bone(name);
        if (bone == null) {
            return null;
        }
        model.reset();
        class_630 arm = side == class_1306.field_6183 ? vanilla.field_3401 : vanilla.field_27433;
        class_5603 armRest = arm.method_41921();
        // Drawn on its own, the bone's pivot is where it is in the whole model, not under its parents.
        float[] rest = restPivot(model, name);
        bone.field_3657 = rest[0] + arm.field_3657 - armRest.field_27702;
        bone.field_3656 = rest[1] + arm.field_3656 - armRest.field_27703;
        bone.field_3655 = rest[2] + arm.field_3655 - armRest.field_27704;
        bone.field_3654 += arm.field_3654 - armRest.field_27705;
        bone.field_3675 += arm.field_3675 - armRest.field_27706;
        bone.field_3674 += arm.field_3674 - armRest.field_27707;
        class_2960 texture = active.replacement().texture();
        draw(() -> bone.method_22698(matrices, consumers.getBuffer(class_1921.method_23578(texture)), light,
                net.minecraft.class_4608.field_21444));
        return new PosedArm(bone, texture);
    }

    /** The layer a replacement is drawn in: see-through where the body is drawn see-through. */
    static class_1921 layer(class_2960 texture, int color) {
        return (color >>> 24) < 255 ? class_1921.method_23580(texture)
                : class_1921.method_23578(texture);
    }

    /** Draws as the replacement: the provider seam leaves these layers alone. */
    private static void draw(Runnable drawing) {
        boolean scoped = ProviderSeam.scoped();
        if (scoped) {
            ProviderSeam.enter(new LayerSource.Replacement());
        }
        try {
            drawing.run();
        } finally {
            if (scoped) {
                ProviderSeam.exit();
            }
        }
    }

    /** Puts a replacement's bones where they are this frame. */
    static void pose(class_1297 entity, Active active, class_583<?> vanilla, float tickDelta) {
        BakedGeo model = active.model();
        ModelReplacement replacement = active.replacement();
        model.reset();
        if (replacement.posing() == ModelReplacement.Posing.ANIMATED) {
            if (replacement.animator() != null && entity instanceof class_1309 living) {
                GeoAnimationState state = STATES.computeIfAbsent(entity, key -> new IdentityHashMap<>())
                        .computeIfAbsent(replacement, key -> new GeoAnimationState());
                state.bind(GeoAssets.animations(replacement.animations()));
                int age = entity.field_6012;
                if (state.lastTick == Integer.MIN_VALUE || age - state.lastTick > 20 || age < state.lastTick) {
                    state.lastTick = age - 1;
                }
                while (state.lastTick < age) {
                    state.lastTick++;
                    state.at(state.lastTick);
                    replacement.animator().tick(living, state);
                }
                state.apply(model, age + tickDelta);
            }
            if (replacement.followLook()) {
                look(model, entity, vanilla, tickDelta);
            }
        } else if (vanilla instanceof class_572<?> biped) {
            GeoRig rig = model.rig();
            if (replacement.followLook()) {
                follow(model, rig.head(), biped.field_3398);
            }
            follow(model, rig.body(), biped.field_3391);
            follow(model, rig.waist(), biped.field_3391);
            follow(model, rig.rightArm(), biped.field_3401);
            follow(model, rig.leftArm(), biped.field_27433);
            follow(model, rig.rightLeg(), biped.field_3392);
            follow(model, rig.leftLeg(), biped.field_3397);
        }
        if (vanilla instanceof class_572<?> biped && partlyHidden(biped)) {
            showAsVanilla(model, biped);
        }
    }

    /**
     * Whether some of the vanilla body is hidden this draw - by a first-person pass, as
     * PlayerAnimator's for Better Combat's swings draws only the arms, or by a spectator's view.
     */
    static boolean partlyHidden(class_572<?> biped) {
        return !(biped.field_3398.field_3665 && biped.field_3391.field_3665 && biped.field_3401.field_3665 && biped.field_27433.field_3665
                && biped.field_3392.field_3665 && biped.field_3397.field_3665);
    }

    /**
     * Shows only the replacement's bones whose vanilla part is showing, and has them follow it: a
     * first-person pass that draws only the arms gets only the replacement's arms, where the vanilla
     * arms are, and nothing else to block the view.
     *
     * <p>A bone the rig does not name shows if what it hangs from does, or with the vanilla body if it
     * hangs from nothing named. A bone that holds a showing bone but does not show itself still
     * carries it, its own cubes hidden.</p>
     */
    static void showAsVanilla(BakedGeo model, class_572<?> biped) {
        GeoRig rig = model.rig();
        Map<String, class_630> vanilla = new HashMap<>();
        putIfNamed(vanilla, rig.head(), biped.field_3398);
        putIfNamed(vanilla, rig.body(), biped.field_3391);
        putIfNamed(vanilla, rig.waist(), biped.field_3391);
        putIfNamed(vanilla, rig.rightArm(), biped.field_3401);
        putIfNamed(vanilla, rig.leftArm(), biped.field_27433);
        putIfNamed(vanilla, rig.rightLeg(), biped.field_3392);
        putIfNamed(vanilla, rig.leftLeg(), biped.field_3397);
        Map<String, String> parents = new HashMap<>();
        for (GeoModel.Bone bone : model.source().bones()) {
            if (bone.parent() != null) {
                parents.put(bone.name(), bone.parent());
            }
        }
        Map<String, Boolean> shown = new HashMap<>();
        for (GeoModel.Bone bone : model.source().bones()) {
            shown(bone.name(), vanilla, parents, biped.field_3391.field_3665, shown);
        }
        // Whatever holds a showing bone has to be drawn for it to be.
        Map<String, Boolean> carries = new HashMap<>();
        for (Map.Entry<String, Boolean> entry : shown.entrySet()) {
            if (entry.getValue()) {
                for (String at = parents.get(entry.getKey()); at != null; at = parents.get(at)) {
                    carries.put(at, true);
                }
            }
        }
        for (Map.Entry<String, Boolean> entry : shown.entrySet()) {
            class_630 part = model.bone(entry.getKey());
            if (part == null) {
                continue;
            }
            boolean show = entry.getValue();
            boolean carry = carries.getOrDefault(entry.getKey(), false);
            part.field_3665 = show || carry;
            part.field_38456 = !show;
            if (!show) {
                // Its rotated cubes sit in parts of their own: hide those with it.
                for (int i = 0; part.method_41919("#cube" + i); i++) {
                    part.method_32086("#cube" + i).field_3665 = false;
                }
            }
        }
        // Showing arms follow the vanilla ones, wherever an animation had put them.
        followShown(model, rig.rightArm(), biped.field_3401);
        followShown(model, rig.leftArm(), biped.field_27433);
    }

    private static void followShown(BakedGeo model, @Nullable String name, class_630 vanilla) {
        class_630 bone = model.bone(name);
        if (bone != null && vanilla.field_3665) {
            bone.method_41923();
            follow(model, name, vanilla);
        }
    }

    private static void putIfNamed(Map<String, class_630> map, @Nullable String name, class_630 part) {
        if (name != null) {
            map.put(name, part);
        }
    }

    private static boolean shown(String bone, Map<String, class_630> vanilla, Map<String, String> parents,
                                 boolean bodyShown, Map<String, Boolean> memo) {
        Boolean known = memo.get(bone);
        if (known != null) {
            return known;
        }
        class_630 part = vanilla.get(bone);
        String parent = parents.get(bone);
        boolean show = part != null ? part.field_3665
                : parent != null ? shown(parent, vanilla, parents, bodyShown, memo) : bodyShown;
        memo.put(bone, show);
        return show;
    }

    /**
     * Moves bone {@code name} as the vanilla part it stands for has moved from its own rest: by the
     * same turn, about the vanilla part's pivot rather than its own - so a bone whose pivot is not
     * quite the vanilla one, or a waist turning with the body from the hips, swings with the body as
     * if it hung from it.
     */
    static void follow(BakedGeo model, @Nullable String name, class_630 part) {
        class_630 bone = model.bone(name);
        if (bone == null) {
            return;
        }
        class_5603 rest = part.method_41921();
        float pitch = part.field_3654 - rest.field_27705;
        float yaw = part.field_3675 - rest.field_27706;
        float roll = part.field_3674 - rest.field_27707;
        // Where the bone's pivot is from the vanilla part's, at rest, and where the turn takes it.
        float[] at = restPivot(model, name);
        Vector3f offset = new Vector3f(at[0] - rest.field_27702, at[1] - rest.field_27703, at[2] - rest.field_27704);
        Vector3f turned = new Quaternionf().rotationZYX(roll, yaw, pitch).transform(new Vector3f(offset));
        bone.field_3657 += part.field_3657 - rest.field_27702 + turned.x - offset.x;
        bone.field_3656 += part.field_3656 - rest.field_27703 + turned.y - offset.y;
        bone.field_3655 += part.field_3655 - rest.field_27704 + turned.z - offset.z;
        bone.field_3654 += pitch;
        bone.field_3675 += yaw;
        bone.field_3674 += roll;
    }

    /** Turns the head bone, if there is one, where the body looks, over whatever it is playing. */
    static void look(BakedGeo model, class_1297 entity, class_583<?> vanilla, float tickDelta) {
        class_630 head = model.bone(model.rig().head());
        if (head == null) {
            return;
        }
        if (vanilla instanceof class_572<?> biped) {
            // The vanilla head already looks where the body does, and where animation mods turn it.
            class_5603 rest = biped.field_3398.method_41921();
            head.field_3675 += biped.field_3398.field_3675 - rest.field_27706;
            head.field_3654 += biped.field_3398.field_3654 - rest.field_27705;
            return;
        }
        if (entity instanceof class_1309 living) {
            float yaw = class_3532.method_15393(class_3532.method_17821(tickDelta, living.field_6259, living.field_6241)
                    - class_3532.method_17821(tickDelta, living.field_6220, living.field_6283));
            head.field_3675 += class_3532.method_15363(yaw, -85.0f, 85.0f) * class_3532.field_29847;
            head.field_3654 += entity.method_5695(tickDelta) * class_3532.field_29847;
        }
    }

    /** Where a bone's pivot is at rest in the whole model: its own offset and its parents'. */
    static float[] restPivot(BakedGeo model, String name) {
        Map<String, String> parents = new HashMap<>();
        for (GeoModel.Bone bone : model.source().bones()) {
            if (bone.parent() != null) {
                parents.put(bone.name(), bone.parent());
            }
        }
        float[] pivot = new float[3];
        for (String at = name; at != null; at = parents.get(at)) {
            class_630 part = model.bone(at);
            if (part == null) {
                break;
            }
            class_5603 rest = part.method_41921();
            pivot[0] += rest.field_27702;
            pivot[1] += rest.field_27703;
            pivot[2] += rest.field_27704;
        }
        return pivot;
    }
}
