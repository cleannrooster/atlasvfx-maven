package dev.eann.atlasvfx;

import net.minecraft.class_310;
import net.minecraft.class_4066;

/**
 * How much of an effect to make, as a share of the whole of it.
 *
 * <p>Two parts multiplied. The game's own particle setting is the base - it is where a player
 * already says "fewer particles", and it holds for every mod drawn this way alike. Each mod then
 * scales its own effects by a share it supplies, from its own settings if it has any; nothing
 * here keeps a setting of its own. What all of them make together is bounded by
 * {@link FxBudget}.</p>
 */
@FunctionalInterface
public interface FxDensity {

    /** A mod's own effects at their full amount. */
    FxDensity FULL = () -> 1.0f;

    /** This mod's own share: 1 for everything it would make, less for less. */
    float share();

    /** The share to make now: the game's setting times this mod's own. */
    default float effective() {
        return vanilla() * Math.max(0.0f, share());
    }

    /** The game's particle setting, as a share of the full effect. */
    static float vanilla() {
        class_4066 mode = class_310.method_1551().field_1690.method_42475().method_41753();
        return switch (mode) {
            case field_18197 -> 1.0f;
            case field_18198 -> 0.5f;
            case field_18199 -> 0.2f;
        };
    }
}
