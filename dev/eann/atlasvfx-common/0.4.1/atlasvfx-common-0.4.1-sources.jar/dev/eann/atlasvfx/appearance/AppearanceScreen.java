package dev.eann.atlasvfx.appearance;

import dev.eann.atlasvfx.character.CharacterEffect;
import dev.eann.atlasvfx.character.CharacterEffects;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_5244;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import net.minecraft.class_8779;

/**
 * Choosing what to be seen as: the appearances there are on the left, each with a small likeness of
 * you wearing it, and on the right a large one of you in whichever is selected, turning to follow
 * the pointer as the inventory's does. Done keeps the choice; Cancel leaves things as they were.
 *
 * <p>Built from the game's own list, buttons and background, so it looks like the game's own
 * screens and follows their theme, blur and narration.</p>
 */
public final class AppearanceScreen extends class_437 {

    private static final int ROW_HEIGHT = 36;
    /** The game's own grey for secondary text. */
    private static final int GRAY = 0xA0A0A0;
    /** Darker, for what cannot be chosen yet. */
    private static final int LOCKED = 0x707070;
    private static final int HEADER = 33;
    private static final int FOOTER = 33;

    private final @Nullable class_437 parent;
    /** Whether it opened by itself on a first join, to ask: it says how to come back to it. */
    private final boolean prompt;
    private @Nullable class_2960 chosen;
    private AppearanceList list;
    private class_4185 done;

    public AppearanceScreen(@Nullable class_437 parent) {
        this(parent, false);
    }

    public AppearanceScreen(@Nullable class_437 parent, boolean prompt) {
        super(class_2561.method_43471("atlasvfx.appearance.title"));
        this.parent = parent;
        this.prompt = prompt;
    }

    @Override
    protected void method_25426() {
        class_746 player = Objects.requireNonNull(field_22787).field_1724;
        class_2960 current = player == null ? null : AppearanceClient.choiceOf(player);
        class_2960 selected = list != null && list.method_25334() != null ? list.method_25334().id() : current;
        chosen = current;
        list = new AppearanceList(field_22787, field_22789 / 2, field_22790 - HEADER - FOOTER, HEADER);
        list.add(null, class_2561.method_43471("atlasvfx.appearance.default"),
                class_2561.method_43471("atlasvfx.appearance.default.description"));
        for (Appearance appearance : Appearances.all()) {
            list.add(appearance.id(), appearance.name(), appearance.description());
        }
        list.select(selected);
        method_37063(list);
        int buttons = field_22790 - FOOTER + 6;
        done = method_37063(class_4185.method_46430(class_5244.field_24334, button -> {
            AppearanceList.Entry entry = list.method_25334();
            class_2960 pick = entry == null ? null : entry.id();
            if (!Objects.equals(pick, chosen) && !AppearanceClient.locked(pick)) {
                AppearanceClient.choose(pick);
            }
            method_25419();
        }).method_46434(field_22789 / 2 - 155, buttons, 150, 20).method_46431());
        method_37063(class_4185.method_46430(class_5244.field_24335, button -> method_25419())
                .method_46434(field_22789 / 2 + 5, buttons, 150, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        if (prompt) {
            context.method_27534(field_22793, field_22785, field_22789 / 2, 6, 0xFFFFFF);
            context.method_27534(field_22793, class_2561.method_43469("atlasvfx.appearance.prompt",
                    AppearanceClient.OPEN.method_16007()), field_22789 / 2, 18, GRAY);
        } else {
            context.method_27534(field_22793, field_22785, field_22789 / 2, 13, 0xFFFFFF);
        }
        class_746 player = field_22787 == null ? null : field_22787.field_1724;
        AppearanceList.Entry selected = list.method_25334();
        // A locked one may be looked at, not chosen.
        done.field_22763 = selected == null || !AppearanceClient.locked(selected.id());
        if (player == null || selected == null) {
            return;
        }
        int left = field_22789 / 2 + 10;
        int right = field_22789 - 10;
        int top = HEADER + 6;
        int bottom = field_22790 - FOOTER - 34;
        int size = Math.max(20, Math.min((bottom - top) * 2 / 5, (right - left) / 2));
        preview(context, selected.id(), player, left, top, right, bottom, size, mouseX, mouseY);
        context.method_27534(field_22793, selected.name(), (left + right) / 2, bottom + 4, 0xFFFFFF);
        if (AppearanceClient.locked(selected.id())) {
            context.method_27534(field_22793, lockedBy(selected.id()), (left + right) / 2, bottom + 16,
                    LOCKED);
        } else if (selected.description() != null) {
            List<class_5481> lines = field_22793.method_1728(selected.description(), right - left);
            for (int i = 0; i < Math.min(2, lines.size()); i++) {
                context.method_35719(field_22793, lines.get(i), (left + right) / 2, bottom + 16 + i * 10,
                        GRAY);
            }
        }
    }

    /** "Locked: <the advancement's title>", or its id if this client does not know it. */
    static class_2561 lockedBy(@Nullable class_2960 appearance) {
        class_2960 advancement = AppearanceClient.requirement(appearance);
        class_2561 name = advancement == null ? class_2561.method_43473() : class_2561.method_43470(advancement.toString());
        class_310 client = class_310.method_1551();
        if (advancement != null && client.method_1562() != null) {
            var entry = client.method_1562().method_2869().method_53815(advancement);
            if (entry != null && entry.comp_1920().comp_1913().isPresent()) {
                name = entry.comp_1920().comp_1913().get().method_811();
            }
        }
        return class_2561.method_43469("atlasvfx.appearance.locked", name);
    }

    /** Draws {@code player} wearing {@code appearance}, as nowhere else sees it: only for this draw. */
    static void preview(class_332 context, @Nullable class_2960 appearance, class_746 player, int x1, int y1,
                        int x2, int y2, int size, float mouseX, float mouseY) {
        Appearance wearing = Appearances.get(appearance);
        CharacterEffect effect = wearing == null ? CharacterEffect.NONE : wearing.effect();
        CharacterEffects.preview(player, effect,
                () -> class_490.method_2486(context, x1, y1, x2, y2, size, 0.0625f, mouseX, mouseY, player));
    }

    @Override
    public void method_25419() {
        if (prompt) {
            // However it is left - Done, Cancel or escape - it has been asked.
            AppearanceClient.prompted();
        }
        Objects.requireNonNull(field_22787).method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    /** The appearances there are, each row with a likeness of the player wearing it. */
    static final class AppearanceList extends class_4280<AppearanceList.Entry> {

        AppearanceList(class_310 client, int width, int height, int y) {
            super(client, width, height, y, ROW_HEIGHT);
        }

        void add(@Nullable class_2960 id, class_2561 name, @Nullable class_2561 description) {
            method_25321(new Entry(id, name, description));
        }

        void select(@Nullable class_2960 id) {
            for (Entry entry : method_25396()) {
                if (Objects.equals(entry.id(), id)) {
                    method_25313(entry);
                    method_25324(entry);
                    return;
                }
            }
            if (!method_25396().isEmpty()) {
                method_25313(method_25396().get(0));
            }
        }

        @Override
        public int method_25322() {
            return Math.min(260, field_22758 - 20);
        }

        final class Entry extends class_4280.class_4281<Entry> {
            private final @Nullable class_2960 id;
            private final class_2561 name;
            private final @Nullable class_2561 description;

            Entry(@Nullable class_2960 id, class_2561 name, @Nullable class_2561 description) {
                this.id = id;
                this.name = name;
                this.description = description;
            }

            @Nullable class_2960 id() {
                return id;
            }

            class_2561 name() {
                return name;
            }

            @Nullable class_2561 description() {
                return description;
            }

            @Override
            public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight,
                               int mouseX, int mouseY, boolean hovered, float tickDelta) {
                class_310 client = class_310.method_1551();
                class_746 player = client.field_1724;
                if (player != null) {
                    // Facing out of the screen, a little to one side, as a portrait.
                    preview(context, id, player, x + 2, y + 1, x + 30, y + entryHeight - 1, 14, x + 26, y + 4);
                }
                boolean locked = AppearanceClient.locked(id);
                context.method_27535(client.field_1772, name, x + 36, y + 5, locked ? GRAY : 0xFFFFFF);
                class_2561 below = locked ? lockedBy(id) : description != null ? description
                        : id == null ? class_2561.method_43473() : class_2561.method_43470(id.toString());
                List<class_5481> lines = client.field_1772.method_1728(below, entryWidth - 40);
                if (!lines.isEmpty()) {
                    context.method_35720(client.field_1772, lines.get(0), x + 36, y + 17, locked ? LOCKED : GRAY);
                }
            }

            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                method_25313(this);
                return true;
            }

            @Override
            public class_2561 method_37006() {
                return class_2561.method_43469("narrator.select", name);
            }
        }
    }
}
