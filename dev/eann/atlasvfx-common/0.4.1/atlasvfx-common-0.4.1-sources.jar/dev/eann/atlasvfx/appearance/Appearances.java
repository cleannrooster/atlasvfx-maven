package dev.eann.atlasvfx.appearance;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.eann.atlasvfx.character.BodyPart;
import dev.eann.atlasvfx.model.ClipAnimator;
import dev.eann.atlasvfx.model.ModelReplacement;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

/**
 * Every appearance there is to choose: those resource packs describe, and those mods register in
 * code. Client side.
 *
 * <p>A resource pack adds one as {@code assets/<namespace>/atlasvfx_appearances/<name>.json}, its id
 * {@code <namespace>:<name>}:</p>
 *
 * <pre>{@code
 * {
 *   "name": "Forsaken Rogue",                         // or a translation key
 *   "description": "A blade in the dark.",            // optional; also may be a key
 *   "geo": "rpg-minibosses:geo/thiefmob.json",
 *   "texture": "rpg-minibosses:textures/mob/thieftexture.png",
 *   "animations": "rpg-minibosses:animations/mobs_v2.animations.json",   // optional
 *   "posing": "follow",                               // the default: the body's own pose,
 *                                                     // or "animated": its own clips
 *   "hides": ["armor", "cape", "elytra", "head", "other"],               // optional
 *   "keep_skin": false,                               // true: drawn over your own skin, as armour is
 *   "clips": {"prefix": "animation.v2.trickster.", "stance": "stance", "advance": "advance",
 *             "backstep": "backstep", "lateral_left": "lateral_left", "lateral_right": "lateral_right",
 *             "swing": ["cross_slash_r", "cross_slash_l"], "use": "throw_mobile", "swing_speed": 1.4}
 * }
 * }</pre>
 *
 * <p>A file that is broken is reported and left out; one registered in code with the same id wins.</p>
 */
public final class Appearances {

    private static final Logger LOGGER = LoggerFactory.getLogger("atlasvfx");
    static final String FOLDER = "atlasvfx_appearances";

    private static volatile Map<class_2960, Appearance> registered = Map.of();
    private static volatile Map<class_2960, Appearance> loaded = Map.of();

    private Appearances() {
    }

    /** Adds one in code, over any resource pack's with the same id. */
    public static synchronized void register(Appearance appearance) {
        Map<class_2960, Appearance> next = new HashMap<>(registered);
        next.put(appearance.id(), appearance);
        registered = Map.copyOf(next);
    }

    public static @Nullable Appearance get(@Nullable class_2960 id) {
        if (id == null) {
            return null;
        }
        Appearance appearance = registered.get(id);
        return appearance != null ? appearance : loaded.get(id);
    }

    /** Every appearance, by name. */
    public static List<Appearance> all() {
        Map<class_2960, Appearance> all = new HashMap<>(loaded);
        all.putAll(registered);
        List<Appearance> list = new ArrayList<>(all.values());
        list.sort(Comparator.comparing((Appearance appearance) -> appearance.name().getString())
                .thenComparing(appearance -> appearance.id().toString()));
        return list;
    }

    /** Reads every appearance resource packs describe. */
    public static void reload(class_3300 manager) {
        Map<class_2960, Appearance> next = new HashMap<>();
        for (Map.Entry<class_2960, class_3298> entry : manager.method_14488(FOLDER,
                path -> path.method_12832().endsWith(".json")).entrySet()) {
            class_2960 file = entry.getKey();
            String path = file.method_12832();
            class_2960 id = class_2960.method_60655(file.method_12836(),
                    path.substring(FOLDER.length() + 1, path.length() - ".json".length()));
            try (Reader reader = entry.getValue().method_43039()) {
                next.put(id, parse(id, JsonParser.parseReader(reader).getAsJsonObject()));
            } catch (Exception e) {
                LOGGER.warn("AtlasVFX could not read appearance {}: {}", file, e.toString());
            }
        }
        loaded = Map.copyOf(next);
    }

    /** One appearance file's contents. */
    public static Appearance parse(class_2960 id, JsonObject json) {
        class_2960 geo = class_2960.method_60654(json.get("geo").getAsString());
        class_2960 texture = class_2960.method_60654(json.get("texture").getAsString());
        class_2960 animations = json.has("animations") ? class_2960.method_60654(json.get("animations").getAsString()) : null;
        Set<BodyPart> hides = EnumSet.copyOf(BodyPart.WORN);
        if (json.has("hides")) {
            hides = EnumSet.of(BodyPart.SKIN, BodyPart.ARM);
            for (JsonElement element : json.getAsJsonArray("hides")) {
                hides.add(BodyPart.valueOf(element.getAsString().toUpperCase(Locale.ROOT)));
            }
        }
        if (json.has("keep_skin") && json.get("keep_skin").getAsBoolean()) {
            // Drawn over the body, as armour is: the skin and first-person arm stay.
            hides.remove(BodyPart.SKIN);
            hides.remove(BodyPart.ARM);
        }
        boolean animated = json.has("posing") && json.get("posing").getAsString().equalsIgnoreCase("animated");
        ClipAnimator animator = json.has("clips") ? ClipAnimator.parse(json.getAsJsonObject("clips")) : null;
        // The clips are kept even when it follows the body, for whoever wants it animated after all.
        ModelReplacement replacement = new ModelReplacement(geo, texture, animations,
                animated && animator != null ? ModelReplacement.Posing.ANIMATED : ModelReplacement.Posing.FOLLOW_BODY,
                animator, hides, true);
        return new Appearance(id, text(json.get("name"), id.toString()),
                json.has("description") ? text(json.get("description"), "") : null, replacement);
    }

    /** A name or a translation key: shown as written when no translation has it. */
    private static class_2561 text(@Nullable JsonElement json, String fallback) {
        String value = json == null ? fallback : json.getAsString();
        return class_2561.method_48321(value, value);
    }
}
