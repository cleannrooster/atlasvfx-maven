package dev.eann.atlasvfx.trail;

import net.minecraft.class_243;

/**
 * Where a swing is anchored and which way it faces, for one instant.
 *
 * @param origin  the point the swing radiates from
 * @param forward the way it faces: the middle of the arc
 * @param up      up, square to {@code forward}
 * @param right   to the right, square to both
 */
public record SweepFrame(class_243 origin, class_243 forward, class_243 up, class_243 right) {

    /**
     * A frame at a point facing a yaw and pitch, built the way the game turns a look into
     * directions - and the way Better Combat builds its attack hitboxes, so an arc drawn from this
     * frame points where such an attack's damage does.
     */
    public static SweepFrame of(class_243 origin, float yaw, float pitch) {
        class_243 forward = class_243.method_1030(pitch, yaw).method_1029();
        class_243 up = class_243.method_1030(pitch + 90.0f, yaw).method_22882().method_1029();
        return new SweepFrame(origin, forward, up, forward.method_1036(up));
    }
}
