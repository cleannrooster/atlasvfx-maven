package dev.eann.atlasvfx.character;

import dev.eann.atlasvfx.parity.LayerSource;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_4073;
import net.minecraft.class_4507;
import net.minecraft.class_9085;
import net.minecraft.class_970;
import net.minecraft.class_972;
import net.minecraft.class_976;
import net.minecraft.class_978;
import net.minecraft.class_979;
import net.minecraft.class_983;
import net.minecraft.class_988;
import net.minecraft.class_989;
import net.minecraft.class_992;
import net.minecraft.class_998;

/**
 * Which body part each feature renderer draws: the game's own are known, a mod names its own with
 * {@link #register}, and anything else is {@link BodyPart#OTHER} - modded layers take a look by
 * default.
 *
 * <p>A renderer counts as what its nearest registered superclass is, so a mod's subclass of the
 * armour renderer is armour without saying so.</p>
 */
public final class BodyParts {

    // Copy-on-write: registered during NeoForge's parallel mod construction, read every frame.
    private static volatile Map<Class<?>, BodyPart> registered = defaults();
    // What each renderer class resolved to; dropped whenever a registration could change it.
    private static final Map<Class<?>, BodyPart> RESOLVED = new ConcurrentHashMap<>();

    private BodyParts() {
    }

    private static Map<Class<?>, BodyPart> defaults() {
        Map<Class<?>, BodyPart> map = new HashMap<>();
        map.put(class_970.class, BodyPart.ARMOR);
        map.put(class_4073.class, BodyPart.ARMOR);
        map.put(class_9085.class, BodyPart.ARMOR);
        map.put(class_988.class, BodyPart.ARMOR);
        map.put(class_992.class, BodyPart.ARMOR);
        map.put(class_972.class, BodyPart.CAPE);
        map.put(class_979.class, BodyPart.ELYTRA);
        map.put(class_976.class, BodyPart.HEAD);
        map.put(class_989.class, BodyPart.HELD);
        map.put(class_4507.class, BodyPart.ATTACHMENT);
        map.put(class_983.class, BodyPart.ATTACHMENT);
        map.put(class_998.class, BodyPart.ATTACHMENT);
        map.put(class_978.class, BodyPart.SKIN);
        // This library's own overlays are drawn over a body, never swapped.
        map.put(OverlayFeatureRenderer.class, BodyPart.ATTACHMENT);
        return Map.copyOf(map);
    }

    /** Says that {@code featureRenderer}, and its subclasses, draw {@code part}. */
    public static synchronized void register(Class<?> featureRenderer, BodyPart part) {
        Map<Class<?>, BodyPart> next = new HashMap<>(registered);
        next.put(featureRenderer, part);
        registered = Map.copyOf(next);
        RESOLVED.clear();
    }

    /**
     * The part a layer asked for by {@code source} is drawn for; null for what is no part of the
     * body at all - the dispatcher's shadow and fire.
     */
    public static @Nullable BodyPart of(@Nullable LayerSource source) {
        if (source instanceof LayerSource.Model) {
            return BodyPart.SKIN;
        }
        if (source instanceof LayerSource.FirstPersonArm) {
            return BodyPart.ARM;
        }
        if (source instanceof LayerSource.Feature feature) {
            return of(feature.renderer());
        }
        return null;
    }

    /** The part a feature renderer of this class draws. */
    public static BodyPart of(Class<?> featureRenderer) {
        return RESOLVED.computeIfAbsent(featureRenderer, BodyParts::resolve);
    }

    private static BodyPart resolve(Class<?> type) {
        Map<Class<?>, BodyPart> map = registered;
        for (Class<?> at = type; at != null; at = at.getSuperclass()) {
            BodyPart part = map.get(at);
            if (part != null) {
                return part;
            }
        }
        return BodyPart.OTHER;
    }
}
