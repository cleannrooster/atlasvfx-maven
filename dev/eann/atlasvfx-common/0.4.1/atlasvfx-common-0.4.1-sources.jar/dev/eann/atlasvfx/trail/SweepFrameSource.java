package dev.eann.atlasvfx.trail;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

/**
 * Where a swing's frame is this frame: read again every time it is drawn, so an arc follows its
 * swinger turning.
 */
@FunctionalInterface
public interface SweepFrameSource {

    /** The frame now, or null when it cannot be found; the last one found is used then. */
    @Nullable
    SweepFrame frame(float tickDelta);

    /**
     * Whether this is the viewer's own swing seen from their own eyes, in which case the part of
     * the arc nearest them would smear across the whole screen and is left out.
     */
    default boolean viewer() {
        return false;
    }

    /** A frame that stays where it is. */
    static SweepFrameSource fixed(SweepFrame frame) {
        return tickDelta -> frame;
    }

    /**
     * An entity's eyes, dropped by a share of its height, facing where it looks - Better Combat's
     * attack origin with a drop of 0.15.
     *
     * @param drop how far below the eyes, as a share of the entity's height
     */
    static SweepFrameSource eyes(class_1297 entity, float drop) {
        return new SweepFrameSource() {
            @Override
            @Nullable
            public SweepFrame frame(float tickDelta) {
                if (entity.method_31481()) {
                    return null;
                }
                class_243 origin = entity.method_5836(tickDelta).method_1023(0.0, entity.method_17682() * drop, 0.0);
                return SweepFrame.of(origin, entity.method_5705(tickDelta), entity.method_5695(tickDelta));
            }

            @Override
            public boolean viewer() {
                class_310 client = class_310.method_1551();
                return entity == client.method_1560() && client.field_1690.method_31044().method_31034();
            }
        };
    }
}
