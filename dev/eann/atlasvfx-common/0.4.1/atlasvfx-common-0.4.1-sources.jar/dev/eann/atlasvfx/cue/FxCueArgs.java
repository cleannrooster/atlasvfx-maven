package dev.eann.atlasvfx.cue;

import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_9129;

/**
 * The arguments every cue gets, sent from the server. Each cue reads the ones it needs: a nova uses
 * {@code at} and {@code size}; a beam, arc or slash also uses {@code to} - an end point, or a
 * direction for a cone or a slash; {@code angle} is a cone's or a slash's half-angle;
 * {@code entityId} lets a cue follow an entity, -1 for none.
 *
 * <p>Safe on a server: nothing here touches the client.</p>
 *
 * @param style the name of the look it is drawn in, as the client registered it with
 *              {@link FxCueStyles}; an unknown one is drawn in the default look
 * @param tier  0 to 2, how much it throws off
 * @param seed  so every client draws the same random detail
 */
public record FxCueArgs(class_2960 style, class_243 at, class_243 to, float size, float angle, int tier, long seed,
                        int entityId) {

    /** A cue at a point. */
    public static FxCueArgs at(class_2960 style, class_243 at, float size, int tier, long seed) {
        return new FxCueArgs(style, at, at, size, 0.0f, tier, seed, -1);
    }

    /** A cue from one point to another: a beam, an arc. */
    public static FxCueArgs between(class_2960 style, class_243 from, class_243 to, float size, int tier, long seed) {
        return new FxCueArgs(style, from, to, size, 0.0f, tier, seed, -1);
    }

    /** A cue thrown one way from a point, within {@code halfAngle} degrees of {@code axis}. */
    public static FxCueArgs cone(class_2960 style, class_243 at, class_243 axis, float halfAngle, float reach, int tier,
                                 long seed) {
        return new FxCueArgs(style, at, axis, reach, halfAngle, tier, seed, -1);
    }

    /** The same cue, following an entity. */
    public FxCueArgs following(int newEntityId) {
        return new FxCueArgs(style, at, to, size, angle, tier, seed, newEntityId);
    }

    public void write(class_9129 buffer) {
        buffer.method_10812(style);
        writeVec(buffer, at);
        writeVec(buffer, to);
        buffer.method_52941(size);
        buffer.method_52941(angle);
        buffer.method_52997(tier);
        buffer.method_52974(seed);
        buffer.method_10804(entityId + 1);
    }

    public static FxCueArgs read(class_9129 buffer) {
        return new FxCueArgs(buffer.method_10810(), readVec(buffer), readVec(buffer), buffer.readFloat(),
                buffer.readFloat(), buffer.readByte(), buffer.readLong(), buffer.method_10816() - 1);
    }

    static void writeVec(class_9129 buffer, class_243 vec) {
        buffer.method_52940(vec.field_1352);
        buffer.method_52940(vec.field_1351);
        buffer.method_52940(vec.field_1350);
    }

    static class_243 readVec(class_9129 buffer) {
        return new class_243(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
    }
}
