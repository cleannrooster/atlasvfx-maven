package dev.eann.atlasvfx.appearance;

import dev.architectury.event.events.client.ClientPlayerEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import dev.architectury.networking.NetworkManager;
import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import dev.eann.atlasvfx.character.CharacterEffect;
import dev.eann.atlasvfx.character.CharacterEffects;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

/**
 * The client's side of appearances: what the server says each player chose, drawn on them; and
 * the key that opens the appearance screen.
 *
 * <p>Only the server's word counts for whether appearances are on: it says so as the client joins.
 * Client thread only.</p>
 */
public final class AppearanceClient {

    public static final class_304 OPEN = new class_304("key.atlasvfx.appearance", class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_O, "key.categories.atlasvfx");

    /**
     * Ticks in a row the game must be quiet - in a world, alive, no screen open - before the first-join
     * prompt opens: long enough for a screen another mod shows on joining to have opened first, and to
     * have the prompt wait behind it.
     */
    static final int QUIET_TICKS = 40;

    private static final Map<UUID, class_2960> CHOICES = new HashMap<>();
    private static Map<class_2960, class_2960> requirements = Map.of();
    private static Set<class_2960> unlocked = Set.of();
    private static boolean enabled;
    private static boolean promptPending;
    private static int quiet;

    private AppearanceClient() {
    }

    public static void init() {
        KeyMappingRegistry.register(OPEN);
        NetworkManager.registerReceiver(NetworkManager.Side.S2C, AppearancePayloads.Sync.ID,
                AppearancePayloads.Sync.CODEC, (payload, context) -> context.queue(() -> sync(payload)));
        NetworkManager.registerReceiver(NetworkManager.Side.S2C, AppearancePayloads.Unlocks.ID,
                AppearancePayloads.Unlocks.CODEC, (payload, context) -> context.queue(() -> {
                    requirements = payload.requirements();
                    unlocked = payload.unlocked();
                }));
        ClientPlayerEvent.CLIENT_PLAYER_QUIT.register(player -> {
            CHOICES.clear();
            requirements = Map.of();
            unlocked = Set.of();
            enabled = false;
            promptPending = false;
            quiet = 0;
        });
        ClientTickEvent.CLIENT_POST.register(AppearanceClient::tick);
        // Drawn on every player who chose one, while appearances are on.
        CharacterEffects.register(entity -> entity instanceof class_1657 player ? effectOf(player) : null);
    }

    /** Whether the server lets players choose an appearance. */
    public static boolean enabled() {
        return enabled;
    }

    /** Whether the player playing has yet to unlock {@code appearance}; never for their own skin. */
    public static boolean locked(@Nullable class_2960 appearance) {
        return appearance != null && requirements.containsKey(appearance) && !unlocked.contains(appearance);
    }

    /** The advancement that unlocks {@code appearance}; null if nothing locks it. */
    public static @Nullable class_2960 requirement(@Nullable class_2960 appearance) {
        return appearance == null ? null : requirements.get(appearance);
    }

    /** What {@code player} chose; null for their own skin. */
    public static @Nullable class_2960 choiceOf(class_1657 player) {
        return CHOICES.get(player.method_5667());
    }

    /** Chooses for the player playing: the server keeps it and shows everyone. */
    public static void choose(@Nullable class_2960 appearance) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || !enabled) {
            return;
        }
        if (NetworkManager.canServerReceive(AppearancePayloads.Choose.ID)) {
            NetworkManager.sendToServer(AppearancePayloads.Choose.of(appearance));
        }
    }

    private static @Nullable CharacterEffect effectOf(class_1657 player) {
        if (!enabled || CHOICES.isEmpty()) {
            return null;
        }
        Appearance appearance = Appearances.get(CHOICES.get(player.method_5667()));
        return appearance == null ? null : appearance.effect();
    }

    /** Tells the server the first-join prompt has been seen, so it is not shown again. */
    static void prompted() {
        if (NetworkManager.canServerReceive(AppearancePayloads.Prompted.ID)) {
            NetworkManager.sendToServer(new AppearancePayloads.Prompted());
        }
    }

    private static void sync(AppearancePayloads.Sync payload) {
        if (payload.full()) {
            CHOICES.clear();
            promptPending = payload.prompt() && payload.enabled();
            quiet = 0;
        }
        enabled = payload.enabled();
        for (Map.Entry<UUID, Optional<class_2960>> entry : payload.choices().entrySet()) {
            if (entry.getValue().isPresent()) {
                CHOICES.put(entry.getKey(), entry.getValue().get());
            } else {
                CHOICES.remove(entry.getKey());
            }
        }
    }

    private static void tick(class_310 client) {
        if (promptPending) {
            waitToPrompt(client);
        }
        while (OPEN.method_1436()) {
            if (client.field_1724 == null || client.field_1755 != null) {
                continue;
            }
            if (!enabled) {
                client.field_1724.method_7353(class_2561.method_43471("atlasvfx.appearance.disabled")
                        .method_27692(class_124.field_1080), true);
                continue;
            }
            client.method_1507(new AppearanceScreen(null, false));
        }
    }

    /**
     * Opens the first-join prompt once the game has been quiet long enough: every tick another mod's
     * screen, a loading screen, or death keeps it waiting starts the count again.
     */
    private static void waitToPrompt(class_310 client) {
        if (!enabled) {
            promptPending = false;
            return;
        }
        boolean quietNow = client.field_1724 != null && client.field_1687 != null && client.field_1755 == null
                && client.field_1724.method_5805() && client.method_18506() == null;
        quiet = quietNow ? quiet + 1 : 0;
        if (quiet >= QUIET_TICKS) {
            promptPending = false;
            quiet = 0;
            client.method_1507(new AppearanceScreen(null, true));
        }
    }
}
