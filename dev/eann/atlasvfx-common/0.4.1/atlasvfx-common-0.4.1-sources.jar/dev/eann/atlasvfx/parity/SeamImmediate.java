package dev.eann.atlasvfx.parity;

import java.util.LinkedHashMap;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;

/**
 * Stands in for the game's batching provider while the seam has an entity wrapped, and is one
 * itself: renderers that check for {@link class_4597.class_4598} to flush a layer early
 * still find one, and every flush goes to the real provider.
 *
 * <p>The buffers the superclass is built with are never used - every method that would touch them
 * is passed on - so they share one small allocation for the life of the game.</p>
 */
final class SeamImmediate extends class_4597.class_4598 implements Seam.Holder {

    private static class_9799 unused;

    private final class_4597.class_4598 delegate;
    private final Seam seam;

    SeamImmediate(class_4597.class_4598 delegate, Seam seam) {
        super(unusedAllocator(), new LinkedHashMap<>());
        this.delegate = delegate;
        this.seam = seam;
    }

    private static class_9799 unusedAllocator() {
        if (unused == null) {
            unused = new class_9799(256);
        }
        return unused;
    }

    @Override
    public class_4588 getBuffer(class_1921 layer) {
        return seam.getBuffer(layer);
    }

    @Override
    public void method_37104() {
        delegate.method_37104();
    }

    @Override
    public void method_22993() {
        delegate.method_22993();
    }

    @Override
    public void method_22994(class_1921 layer) {
        delegate.method_22994(layer);
    }

    @Override
    public Seam seam() {
        return seam;
    }
}
