package dev.eann.atlasvfx.model;

import dev.eann.atlasvfx.character.BodyPart;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_2960;

/**
 * A body drawn as another model: a geometry file in place of the skin - and, as chosen, of armour,
 * cape and the rest - posed by the body it replaces or by its own animations.
 *
 * <p>The vanilla body is not cancelled: every renderer and every mod's hook on it still runs, and
 * only the layers of the parts in {@link #hides} are left undrawn. If the model cannot be loaded the
 * body is drawn as it always was.</p>
 *
 * @param geo        a geometry file, e.g. {@code mymod:geo/rogue.geo.json}
 * @param texture    the texture it is drawn in
 * @param animations an animation file for {@link Posing#ANIMATED}; null for none
 * @param animator   what it plays when, for {@link Posing#ANIMATED}; null to hold its rest pose
 * @param hides      the body's own parts left undrawn - the skin and first-person arm too, unless it
 *                   is drawn over them, as armour is
 * @param followLook whether its head - if it has a plainly named one - turns where the body looks
 */
public record ModelReplacement(class_2960 geo, class_2960 texture, @Nullable class_2960 animations, Posing posing,
                               @Nullable GeoAnimator animator, Set<BodyPart> hides, boolean followLook) {

    public enum Posing {
        /**
         * Head, body, arms and legs follow the vanilla body's pose: walking, sneaking, swinging,
         * and every pose an animation mod gives the vanilla model.
         */
        FOLLOW_BODY,
        /** Its own animations pose it; only the head still follows where the body looks. */
        ANIMATED
    }

    public ModelReplacement {
        hides = Set.copyOf(hides);
    }

    /** A model that follows the body, hiding everything it is seen as but what it holds. */
    public static ModelReplacement following(class_2960 geo, class_2960 texture) {
        return new ModelReplacement(geo, texture, null, Posing.FOLLOW_BODY, null, BodyPart.WORN, true);
    }

    /** A model that plays its own animations, chosen by {@code animator}. */
    public static ModelReplacement animated(class_2960 geo, class_2960 texture, class_2960 animations,
                                            GeoAnimator animator) {
        return new ModelReplacement(geo, texture, animations, Posing.ANIMATED, animator, BodyPart.WORN, true);
    }

    /** Whether the body's own layers for {@code part} are left undrawn. */
    public boolean hides(BodyPart part) {
        return hides.contains(part);
    }

    public ModelReplacement hiding(Set<BodyPart> parts) {
        return new ModelReplacement(geo, texture, animations, posing, animator, parts, followLook);
    }
}
