package dev.eann.atlasvfx.parity;

import dev.architectury.event.events.client.ClientCommandRegistrationEvent.ClientCommandSourceStack;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_746;
import net.minecraft.class_7923;

/**
 * {@code /atlasvfx parity [self|target|arm] [diff <name|last>]}: captures one frame of an entity's
 * layers, lists them in chat and saves them under {@code atlasvfx/parity/} in the game folder.
 *
 * <ul>
 *   <li>{@code target} - the entity under the crosshair; the default when there is one.</li>
 *   <li>{@code self} - the player, in third person (in first person the body is not drawn).</li>
 *   <li>{@code arm} - the player's first-person arm, drawn when the hand is empty.</li>
 *   <li>{@code diff <name>} - also compares the capture with a saved one; {@code last} is the most
 *       recent saved.</li>
 * </ul>
 */
@ApiStatus.Internal
public final class ParityCommand {

    private static final int TIMEOUT_FRAMES = 40;
    private static final int MAX_LINES = 40;
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private ParityCommand() {
    }

    public static int run(ClientCommandSourceStack source, String options) {
        class_310 client = class_310.method_1551();
        class_746 player = source.arch$getPlayer();
        if (player == null || source.arch$getLevel() == null) {
            return 0;
        }
        String subject = null;
        String diff = null;
        String[] words = options.trim().toLowerCase(Locale.ROOT).split("\\s+");
        for (int i = 0; i < words.length; i++) {
            switch (words[i]) {
                case "" -> {
                }
                case "self", "target", "arm" -> subject = words[i];
                case "diff" -> {
                    if (i + 1 >= words.length) {
                        source.arch$sendFailure(class_2561.method_43470("diff needs a saved capture's name, or last"));
                        return 0;
                    }
                    diff = words[++i];
                }
                default -> {
                    source.arch$sendFailure(class_2561.method_43470("Unknown option: " + words[i]
                            + " (self, target, arm, diff <name|last>)"));
                    return 0;
                }
            }
        }
        class_1297 target = client.field_1692;
        if (subject == null) {
            subject = target != null ? "target" : "self";
        }
        class_1297 entity = switch (subject) {
            case "target" -> target;
            default -> player;
        };
        if (entity == null) {
            source.arch$sendFailure(class_2561.method_43470("Nothing under the crosshair"));
            return 0;
        }
        if (subject.equals("self") && client.field_1690.method_31044().method_31034()) {
            source.arch$sendFailure(class_2561.method_43470("Your body is not drawn in first person: press F5, or use 'arm'"));
            return 0;
        }
        Path dir = directory(client);
        ParityCapture.Mode mode = subject.equals("arm") ? ParityCapture.Mode.ARM : ParityCapture.Mode.ENTITY;
        ParityReport baseline = null;
        if (diff != null) {
            try {
                Path file = resolve(dir, diff, prefix(class_7923.field_41177.method_10221(entity.method_5864()).toString(), mode));
                if (file == null) {
                    source.arch$sendFailure(class_2561.method_43470(diff.equals("last") ? "No earlier capture of this in " + dir
                            : "No saved capture called " + diff + " in " + dir));
                    return 0;
                }
                baseline = ParityReport.read(file);
            } catch (IOException | RuntimeException e) {
                source.arch$sendFailure(class_2561.method_43470("Could not read " + diff + ": " + e.getMessage()));
                return 0;
            }
        }
        ParityReport before = baseline;
        ParityCapture.arm(entity.method_5628(), mode, TIMEOUT_FRAMES, outcome -> deliver(client, dir, outcome, before));
        String what = mode == ParityCapture.Mode.ARM ? "your arm" : entity.method_5477().getString();
        source.arch$sendSuccess(() -> class_2561.method_43470("Capturing " + what + " on the next frame")
                .method_27692(class_124.field_1080), false);
        return 1;
    }

    private static void deliver(class_310 client, Path dir, ParityCapture.Outcome outcome,
                                @Nullable ParityReport baseline) {
        class_746 player = client.field_1724;
        if (player == null) {
            return;
        }
        if (outcome instanceof ParityCapture.Outcome.TimedOut timedOut) {
            player.method_7353(class_2561.method_43470("Not drawn in " + timedOut.frames() + " frames"
                    + (timedOut.mode() == ParityCapture.Mode.ARM ? ": empty your main hand and stay in first person"
                    : ": is it on screen?")).method_27692(class_124.field_1061), false);
            return;
        }
        ParityReport report = ((ParityCapture.Outcome.Captured) outcome).report();
        for (class_2561 line : summary(report)) {
            player.method_7353(line, false);
        }
        try {
            Path file = dir.resolve(prefix(report.entity(), report.mode()) + LocalDateTime.now().format(STAMP) + ".json");
            report.write(file);
            player.method_7353(class_2561.method_43470("Saved ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470(
                    file.getFileName().toString()).method_27692(class_124.field_1073).method_27694(style -> style.method_10958(
                    new class_2558(class_2558.class_2559.field_11746, file.toAbsolutePath().toString())))), false);
        } catch (IOException | UncheckedIOException e) {
            player.method_7353(class_2561.method_43470("Could not save the capture: " + e.getMessage()).method_27692(class_124.field_1061),
                    false);
        }
        if (baseline != null) {
            List<String> changes = report.diff(baseline);
            player.method_7353(class_2561.method_43470(changes.isEmpty() ? "Same layers as the saved capture"
                    : changes.size() + " change(s) from the saved capture:").method_27692(class_124.field_1065), false);
            for (String change : changes.subList(0, Math.min(changes.size(), MAX_LINES))) {
                player.method_7353(class_2561.method_43470(change).method_27692(change.startsWith("+") ? class_124.field_1060
                        : change.startsWith("-") ? class_124.field_1061 : class_124.field_1054), false);
            }
        }
    }

    static List<class_2561> summary(ParityReport report) {
        StringBuilder counts = new StringBuilder();
        for (Map.Entry<LayerClass, Integer> entry : report.counts().entrySet()) {
            counts.append(counts.isEmpty() ? "" : ", ").append(entry.getValue()).append(' ')
                    .append(entry.getKey().name().toLowerCase(Locale.ROOT));
        }
        String provider = report.provider().substring(report.provider().lastIndexOf('.') + 1);
        class_5250 header = class_2561.method_43470("Parity: " + report.entity() + " (" + report.mode() + "), "
                + report.uses().size() + " layer requests").method_27692(class_124.field_1065);
        List<class_2561> lines = new java.util.ArrayList<>();
        lines.add(header);
        lines.add(class_2561.method_43470(counts + " | " + report.loader() + ", provider " + provider
                + (report.iris() ? ", Iris" + (report.shaderPack() ? " with a pack" : " without a pack") : "")
                + (report.sodium() ? ", Sodium" : "")).method_27692(class_124.field_1080));
        for (LayerUse use : report.uses().subList(0, Math.min(report.uses().size(), MAX_LINES))) {
            lines.add(class_2561.method_43470("#" + use.order() + " ").method_27692(class_124.field_1063)
                    .method_10852(class_2561.method_43470(use.layerClass().name()).method_27692(colour(use.layerClass())))
                    .method_10852(class_2561.method_43470(" " + use.source() + ": ").method_27692(class_124.field_1080))
                    .method_10852(class_2561.method_43470(use.layerName()))
                    .method_10852(class_2561.method_43470(use.drawnAs() == null ? "" : " -> " + use.drawnAs())
                            .method_27692(class_124.field_1076))
                    .method_10852(class_2561.method_43470((use.texture() == null ? "" : " " + use.texture()) + " (" + use.vertices()
                            + ", " + use.reason() + ")").method_27692(class_124.field_1063)));
        }
        if (report.uses().size() > MAX_LINES) {
            lines.add(class_2561.method_43470("... " + (report.uses().size() - MAX_LINES) + " more in the file")
                    .method_27692(class_124.field_1080));
        }
        return lines;
    }

    private static class_124 colour(LayerClass layerClass) {
        return switch (layerClass) {
            case SURFACE -> class_124.field_1060;
            case TRANSLUCENT_SURFACE -> class_124.field_1075;
            case EFFECT_OVERLAY -> class_124.field_1076;
            case UNKNOWN -> class_124.field_1054;
        };
    }

    private static Path directory(class_310 client) {
        return client.field_1697.toPath().resolve("atlasvfx").resolve("parity");
    }

    /** What every saved capture of one entity type in one mode is named starting with. */
    private static String prefix(String entity, ParityCapture.Mode mode) {
        return prefix(entity, mode.name().toLowerCase(Locale.ROOT));
    }

    private static String prefix(String entity, String mode) {
        return entity.replace(':', '_') + "_" + mode + "_";
    }

    /**
     * A saved capture by name, or for {@code last} the newest of the same entity type and mode -
     * comparing a body with an arm, or a zombie with a player, says nothing. Null when there is none.
     */
    private static @Nullable Path resolve(Path dir, String name, String lastPrefix) throws IOException {
        if (!Files.isDirectory(dir)) {
            return null;
        }
        if (name.equals("last")) {
            try (Stream<Path> files = Files.list(dir)) {
                return files.filter(file -> file.getFileName().toString().startsWith(lastPrefix)
                                && file.getFileName().toString().endsWith(".json"))
                        .max(Comparator.comparing(file -> file.toFile().lastModified())).orElse(null);
            }
        }
        // Names only: a capture lives in this folder, and nothing outside it is read.
        if (name.contains("/") || name.contains("\\") || name.contains("..")) {
            return null;
        }
        Path file = dir.resolve(name.endsWith(".json") ? name : name + ".json");
        return Files.isRegularFile(file) ? file : null;
    }
}
