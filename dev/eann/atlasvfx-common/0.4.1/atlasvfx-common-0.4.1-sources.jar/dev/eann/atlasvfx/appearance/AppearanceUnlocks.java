package dev.eann.atlasvfx.appearance;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_8779;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Which appearances are earned, and by what: an advancement a player has to have done before they
 * may choose it. Server side, and safe on a dedicated server.
 *
 * <p>A data pack locks one as {@code data/<namespace>/atlasvfx_unlocks/<name>.json}, for the
 * appearance {@code <namespace>:<name>}:</p>
 *
 * <pre>{@code
 * { "advancement": "minecraft:story/mine_diamond" }
 * }</pre>
 *
 * <p>An appearance nothing locks is open to everyone. In data, not with the appearance's look in a
 * resource pack: the server decides who may wear what, and a dedicated server reads no resource
 * packs. An advancement that does not exist - its mod not installed - locks nothing, rather than
 * locking it for good; it is reported once.</p>
 */
public final class AppearanceUnlocks {

    private static final Logger LOGGER = LoggerFactory.getLogger("atlasvfx");
    static final String FOLDER = "atlasvfx_unlocks";

    private static volatile Map<class_2960, class_2960> requirements = Map.of();
    private static final Set<class_2960> REPORTED = new HashSet<>();

    private AppearanceUnlocks() {
    }

    /** Each locked appearance, with the advancement that unlocks it. */
    public static Map<class_2960, class_2960> requirements() {
        return requirements;
    }

    /** What unlocks {@code appearance}; null if nothing locks it. */
    public static @Nullable class_2960 requirement(class_2960 appearance) {
        return requirements.get(appearance);
    }

    /** Whether {@code player} may wear {@code appearance}. */
    public static boolean unlocked(class_3222 player, class_2960 appearance) {
        class_2960 advancement = requirements.get(appearance);
        if (advancement == null) {
            return true;
        }
        MinecraftServer server = player.method_5682();
        class_8779 entry = server == null ? null : server.method_3851().method_12896(advancement);
        if (entry == null) {
            synchronized (REPORTED) {
                if (REPORTED.add(advancement)) {
                    LOGGER.warn("AtlasVFX: appearance {} is unlocked by {}, which does not exist; it is left unlocked",
                            appearance, advancement);
                }
            }
            return true;
        }
        return player.method_14236().method_12882(entry).method_740();
    }

    /** Every locked appearance {@code player} has unlocked. */
    public static Set<class_2960> unlockedBy(class_3222 player) {
        Set<class_2960> unlocked = new HashSet<>();
        for (class_2960 appearance : requirements.keySet()) {
            if (unlocked(player, appearance)) {
                unlocked.add(appearance);
            }
        }
        return unlocked;
    }

    /** Whether earning {@code advancement} unlocks anything. */
    static boolean unlocksAnything(class_2960 advancement) {
        return requirements.containsValue(advancement);
    }

    /** Reads every unlock data packs give. */
    public static void reload(class_3300 manager) {
        Map<class_2960, class_2960> next = new HashMap<>();
        for (Map.Entry<class_2960, class_3298> entry : manager.method_14488(FOLDER,
                path -> path.method_12832().endsWith(".json")).entrySet()) {
            class_2960 file = entry.getKey();
            String path = file.method_12832();
            class_2960 appearance = class_2960.method_60655(file.method_12836(),
                    path.substring(FOLDER.length() + 1, path.length() - ".json".length()));
            try (Reader reader = entry.getValue().method_43039()) {
                next.put(appearance, parse(JsonParser.parseReader(reader).getAsJsonObject()));
            } catch (Exception e) {
                LOGGER.warn("AtlasVFX could not read appearance unlock {}: {}", file, e.toString());
            }
        }
        requirements = Map.copyOf(next);
        synchronized (REPORTED) {
            REPORTED.clear();
        }
    }

    /** One unlock file's advancement. */
    static class_2960 parse(JsonObject json) {
        return class_2960.method_60654(json.get("advancement").getAsString());
    }
}
