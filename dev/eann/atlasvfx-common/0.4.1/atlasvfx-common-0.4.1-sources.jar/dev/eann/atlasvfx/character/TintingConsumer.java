package dev.eann.atlasvfx.character;

import net.minecraft.class_4588;

/**
 * Passes every vertex on with its colour multiplied by a tint, alpha included: how a look makes a
 * body see-through or coloured without touching its geometry. Only handed out for a tinted swap.
 */
final class TintingConsumer implements class_4588 {

    private final class_4588 delegate;
    private final int argb;

    TintingConsumer(class_4588 delegate, int argb) {
        this.delegate = delegate;
        this.argb = argb;
    }

    /** {@code color}, ARGB, multiplied by {@code tint}, ARGB. */
    static int multiply(int color, int tint) {
        int a = (color >>> 24) * (tint >>> 24) / 255;
        int r = (color >> 16 & 0xFF) * (tint >> 16 & 0xFF) / 255;
        int g = (color >> 8 & 0xFF) * (tint >> 8 & 0xFF) / 255;
        int b = (color & 0xFF) * (tint & 0xFF) / 255;
        return a << 24 | r << 16 | g << 8 | b;
    }

    @Override
    public class_4588 method_22912(float x, float y, float z) {
        delegate.method_22912(x, y, z);
        return this;
    }

    @Override
    public void method_23919(float x, float y, float z, int color, float u, float v, int overlay, int light,
                       float normalX, float normalY, float normalZ) {
        delegate.method_23919(x, y, z, multiply(color, argb), u, v, overlay, light, normalX, normalY, normalZ);
    }

    @Override
    public class_4588 method_1336(int red, int green, int blue, int alpha) {
        int tinted = multiply(alpha << 24 | red << 16 | green << 8 | blue, argb);
        delegate.method_1336(tinted >> 16 & 0xFF, tinted >> 8 & 0xFF, tinted & 0xFF, tinted >>> 24);
        return this;
    }

    @Override
    public class_4588 method_22913(float u, float v) {
        delegate.method_22913(u, v);
        return this;
    }

    @Override
    public class_4588 method_60796(int u, int v) {
        delegate.method_60796(u, v);
        return this;
    }

    @Override
    public class_4588 method_22921(int u, int v) {
        delegate.method_22921(u, v);
        return this;
    }

    @Override
    public class_4588 method_22914(float x, float y, float z) {
        delegate.method_22914(x, y, z);
        return this;
    }
}
