package dev.eann.atlasvfx.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import dev.eann.atlasvfx.character.CharacterEffects;
import dev.eann.atlasvfx.model.Replacements;
import dev.eann.atlasvfx.parity.ProviderSeam;
import net.minecraft.class_1007;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;

/**
 * First-person arms, which the world's entity pass never draws: the provider seam, and the body's
 * overlays drawn over the arm.
 */
@Mixin(class_1007.class)
abstract class PlayerEntityRendererMixin {

    @WrapMethod(method = {"renderRightArm", "renderRightHand"})
    private void atlasvfx$seamRightArm(class_4587 matrices, class_4597 provider, int light,
                                       class_742 player, Operation<Void> original) {
        arm(class_1306.field_6183, matrices, provider, light, player, original);
    }

    @WrapMethod(method = {"renderLeftArm", "renderLeftHand"})
    private void atlasvfx$seamLeftArm(class_4587 matrices, class_4597 provider, int light,
                                      class_742 player, Operation<Void> original) {
        arm(class_1306.field_6182, matrices, provider, light, player, original);
    }

    private void arm(class_1306 side, class_4587 matrices, class_4597 provider, int light,
                     class_742 player, Operation<Void> original) {
        class_4597 wrapped = ProviderSeam.wrapArm(player, side, provider);
        try {
            original.call(matrices, wrapped, light, player);
            overlays(side, matrices, wrapped, light, player);
        } finally {
            if (wrapped != provider) {
                ProviderSeam.finish(wrapped);
            }
        }
    }

    /**
     * A replacement's arm in place of the one just drawn, if the body is replaced; then the body's
     * overlays over whichever arm is showing, as they are over the rest of it in third person.
     */
    private void overlays(class_1306 side, class_4587 matrices, class_4597 consumers, int light,
                          class_742 player) {
        if (!CharacterEffects.any()) {
            return;
        }
        class_591<class_742> model = ((class_1007) (Object) this).method_4038();
        Replacements.PosedArm replaced = Replacements.drawArm(player, side, model, matrices, consumers, light);
        if (replaced != null) {
            CharacterEffects.drawArm(player, replaced.bone(), null, replaced.texture(), matrices, consumers, light);
            return;
        }
        CharacterEffects.drawArm(player, side == class_1306.field_6183 ? model.field_3401 : model.field_27433,
                side == class_1306.field_6183 ? model.field_3486 : model.field_3484, player.method_52814().comp_1626(),
                matrices, consumers, light);
    }
}
