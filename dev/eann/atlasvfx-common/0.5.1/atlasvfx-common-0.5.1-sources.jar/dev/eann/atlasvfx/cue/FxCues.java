package dev.eann.atlasvfx.cue;

import dev.eann.atlasvfx.AtlasVfxCommon;
import net.minecraft.class_2960;

/**
 * The names of the built-in cues - one per generic shape, drawn in whatever style the server names
 * - and of the built-in looks. Safe on a server.
 *
 * <p>A mod with something bespoke registers its own cue name with {@link FxCueHandlers} on the
 * client and sends it with {@link FxEmitter} exactly like these.</p>
 */
public final class FxCues {

    /** A blink and a ring: a hit, a cast going off. {@code at}, {@code size}. */
    public static final class_2960 PULSE = id("pulse");
    /** A ring running out across the ground. {@code at}, {@code size} is its radius. */
    public static final class_2960 NOVA = id("nova");
    /** A bloom with debris. {@code at}, {@code size}. */
    public static final class_2960 EXPLOSION = id("explosion");
    /** A shaft of light rising from {@code at}. */
    public static final class_2960 BLAST = id("blast");
    /** A shaft of light falling onto {@code at}: a meteor landing. */
    public static final class_2960 BLAST_FALLING = id("blast_falling");
    /** A straight beam from {@code at} to {@code to}; {@code size} is its width. */
    public static final class_2960 BEAM = id("beam");
    /** A jagged arc from {@code at} to {@code to}. */
    public static final class_2960 ARC = id("arc");
    /** A blast one way: {@code at}, along {@code to}, {@code angle} either side, {@code size} far. */
    public static final class_2960 CONE = id("cone");
    /** Debris thrown out from {@code at} within {@code size}. */
    public static final class_2960 BURST = id("burst");
    /** Motes drifting within {@code size} of {@code at}: something lingering. */
    public static final class_2960 WISP = id("wisp");
    /** Smoke rising over {@code size} around {@code at}; the style is ignored. */
    public static final class_2960 SMOKE = id("smoke");
    /** The style's falling motes over {@code size} around {@code at}. */
    public static final class_2960 RAIN = id("rain");
    /**
     * A level blade trail from {@code at}, facing along {@code to}, reaching {@code size} blocks
     * through {@code angle} degrees either side; {@code tier} 1 sweeps from the right.
     */
    public static final class_2960 SLASH = id("slash");
    /**
     * Something struck at {@code at} by a blow travelling along {@code to} (a direction): the
     * style's debris skimming on along the surface, its accent glancing straight out of it, and a
     * hard white glint. With an entity to follow, the surface is that entity's body and the glint
     * rides along with it; without, it is the block the blow ran into. Make the arguments with
     * {@link FxCueArgs#impact}.
     */
    public static final class_2960 IMPACT = id("impact");

    /** The look of something that hurts: red. For cues, the default style. */
    public static final class_2960 DANGER = id("danger");
    /** The look of something coming: amber. */
    public static final class_2960 WARNING = id("warning");
    /** The look of something that helps: green. */
    public static final class_2960 HELPFUL = id("helpful");
    /** The look of something struck: white-hot sparks cooling to orange, chips and dust. */
    public static final class_2960 SPARKS = id("sparks");

    private FxCues() {
    }

    private static class_2960 id(String name) {
        return class_2960.method_60655(AtlasVfxCommon.MOD_ID, name);
    }
}
