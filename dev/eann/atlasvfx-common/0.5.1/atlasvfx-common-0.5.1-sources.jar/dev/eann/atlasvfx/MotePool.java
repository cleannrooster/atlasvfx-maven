package dev.eann.atlasvfx;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_243;
import net.minecraft.class_638;

/**
 * Motes alive together: ticked together and drawn together.
 *
 * <p>Holds at most its own ceiling, and never more than {@link FxBudget} has room for across
 * every pool; past either, a new mote is simply not made.</p>
 */
public final class MotePool {

    /** The longest a streak is drawn, in blocks, so a mote moved a long way in a tick never paints across the view. */
    static final double MAX_STREAK = 2.0;

    private final int cap;
    private final List<Mote> motes = new ArrayList<>();

    /** @param cap the most this pool holds at once */
    public MotePool(int cap) {
        this.cap = cap;
    }

    /** Whether one more mote would be kept. */
    public boolean hasRoom() {
        return motes.size() < cap && FxBudget.hasRoom();
    }

    /** Keeps a mote if there is room for it; false if it was not kept. */
    public boolean add(Mote mote) {
        if (motes.size() >= cap || !FxBudget.tryReserve()) {
            return false;
        }
        motes.add(mote);
        return true;
    }

    /** Advances every mote a tick; the spent ones go, and anchored ones whose anchor let go fade. */
    public void tick() {
        int gone = 0;
        Iterator<Mote> iterator = motes.iterator();
        while (iterator.hasNext()) {
            Mote mote = iterator.next();
            FxAnchor anchor = mote.anchor();
            if (anchor != null && !anchor.held()) {
                mote.letGo();
            }
            if (!mote.tick()) {
                iterator.remove();
                gone++;
            }
        }
        FxBudget.release(gone);
    }

    public void clear() {
        FxBudget.release(motes.size());
        motes.clear();
    }

    public boolean isEmpty() {
        return motes.isEmpty();
    }

    public int size() {
        return motes.size();
    }

    /** Whether any is drawn into the first-person view. */
    public boolean anyInView() {
        for (Mote mote : motes) {
            if (mote.inView()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Draws the motes that belong to one place: those out in the world, or those drawn into the
     * first-person view. Each anchor is found once, however many motes it holds.
     *
     * @param world     the world, for the light lit motes are drawn in; null in the view
     * @param inView    which place to draw
     * @param viewLight the light lit motes are drawn in when there is no world to ask
     */
    public void draw(FxPainter painter, @Nullable class_638 world, boolean inView, float tickDelta,
                     int viewLight) {
        Map<FxAnchor, class_243> anchors = new HashMap<>();
        for (Mote mote : motes) {
            if (mote.inView() != inView) {
                continue;
            }
            FxAnchor anchor = mote.anchor();
            class_243 at;
            if (anchor != null) {
                class_243 base = anchors.computeIfAbsent(anchor, key -> key.position(tickDelta));
                if (base == null) {
                    continue;
                }
                at = base.method_1019(mote.offsetOrPosition(tickDelta));
            } else {
                at = mote.offsetOrPosition(tickDelta);
            }
            draw(painter, world, mote, at, tickDelta, viewLight);
        }
    }

    /** One mote, at a point already worked out. */
    public static void draw(FxPainter painter, @Nullable class_638 world, Mote mote, class_243 at, float tickDelta,
                            int viewLight) {
        MoteRecipe recipe = mote.recipe();
        MoteProfile profile = recipe.profile();
        if (profile.draw() == MoteDraw.STREAK) {
            streak(painter, mote, profile, at, tickDelta);
            return;
        }
        if (recipe.sprite() == null && recipe.blend() != FxBlend.GLOW) {
            return;
        }
        float alpha = mote.alpha(tickDelta);
        float size = mote.drawnSize(tickDelta);
        int colour = mote.colour(tickDelta);
        int light;
        if (recipe.blend() != FxBlend.LIT) {
            light = FxLight.FULL_BRIGHT;
        } else {
            light = world != null ? FxLight.at(world, at) : viewLight;
        }
        if (recipe.blend() == FxBlend.GLOW || recipe.sprite() == null) {
            painter.glow(at, size * 0.5f, colour, alpha);
            return;
        }
        painter.sprite(recipe.blend(), recipe.sprite(), mote.lifeFraction(tickDelta), mote.pick(), recipe.flips(),
                at, size, mote.roll(tickDelta), colour, alpha, light, recipe.crumb());
    }

    /**
     * One mote as a line back along the way it is going: as long as it moves in its profile's
     * streak ticks, never shorter than it is thick nor longer than {@link #MAX_STREAK}. One that
     * has stopped is a spot of light its own thickness.
     */
    private static void streak(FxPainter painter, Mote mote, MoteProfile profile, class_243 at, float tickDelta) {
        float width = mote.drawnSize(tickDelta);
        float alpha = mote.alpha(tickDelta);
        int colour = mote.colour(tickDelta);
        class_243 velocity = mote.velocity(tickDelta);
        double speed = velocity.method_1033();
        double length = streakLength(speed, profile.streakTicks(), width);
        if (speed < 1.0e-6) {
            painter.glow(at, width * 0.5f, colour, alpha);
            return;
        }
        class_243 tail = at.method_1020(velocity.method_1021(length / speed));
        painter.streak(at, tail, width, colour, alpha, alpha * (1.0f - profile.tailFade()));
    }

    /** How long a streak is drawn: its speed over its ticks, kept between its thickness and {@link #MAX_STREAK}. */
    static double streakLength(double speed, float ticks, float width) {
        return Math.min(MAX_STREAK, Math.max(width, speed * ticks));
    }
}
