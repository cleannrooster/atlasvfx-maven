package dev.eann.atlasvfx;

import net.minecraft.class_238;
import net.minecraft.class_243;

/**
 * Where things go when something is struck: which way a surface faces, and which way a spray
 * glances off it. The geometry under {@link FxShapes#impact}. Pure arithmetic, so it can be tested
 * without a game.
 */
public final class FxSurface {

    private static final class_243 UP = new class_243(0.0, 1.0, 0.0);

    private FxSurface() {
    }

    /**
     * The outward way a struck surface faces, of unit length: {@code normal} if it has a length,
     * else straight back against {@code incoming}, else up.
     */
    public static class_243 facing(class_243 incoming, class_243 normal) {
        if (normal.method_1027() > 1.0e-8) {
            return normal.method_1029();
        }
        if (incoming.method_1027() > 1.0e-8) {
            return incoming.method_1029().method_22882();
        }
        return UP;
    }

    /**
     * The part of a blow that runs along the surface it struck, of unit length: {@code incoming}
     * with its push into the surface taken out. A blow straight into the surface runs along it
     * nowhere, and any direction lying in the surface is given instead.
     */
    public static class_243 along(class_243 incoming, class_243 normal) {
        class_243 n = facing(incoming, normal);
        class_243 flat = incoming.method_1020(n.method_1021(incoming.method_1026(n)));
        if (flat.method_1027() > 1.0e-4 * Math.max(1.0e-8, incoming.method_1027())
                && flat.method_1027() > 1.0e-10) {
            return flat.method_1029();
        }
        class_243 helper = Math.abs(n.field_1351) < 0.9 ? UP : new class_243(1.0, 0.0, 0.0);
        return helper.method_1036(n).method_1029();
    }

    /**
     * The way a spray leaves a struck surface, of unit length: on along the surface the way the
     * blow was going, leaning {@code lean} out of it - 0 skims flat along it, 1 leaves at 45
     * degrees. A blow straight into the surface sprays straight back out of it.
     */
    public static class_243 glanceAxis(class_243 incoming, class_243 normal, double lean) {
        class_243 n = facing(incoming, normal);
        class_243 flat = incoming.method_1020(n.method_1021(incoming.method_1026(n)));
        if (flat.method_1027() <= 1.0e-4 * Math.max(1.0e-8, incoming.method_1027())
                || flat.method_1027() <= 1.0e-10) {
            return n;
        }
        return flat.method_1029().method_1019(n.method_1021(lean)).method_1029();
    }

    /**
     * The outward way the face of a box struck at {@code at} faces: the face nearest the point
     * among those turned towards the blow. With no blow, the nearest face of all.
     *
     * @param incoming the way the blow was going; need not be of unit length
     */
    public static class_243 boxNormal(class_238 box, class_243 at, class_243 incoming) {
        class_243[] normals = {
                new class_243(-1.0, 0.0, 0.0), new class_243(1.0, 0.0, 0.0),
                new class_243(0.0, -1.0, 0.0), new class_243(0.0, 1.0, 0.0),
                new class_243(0.0, 0.0, -1.0), new class_243(0.0, 0.0, 1.0)};
        double[] distances = {
                Math.abs(at.field_1352 - box.field_1323), Math.abs(at.field_1352 - box.field_1320),
                Math.abs(at.field_1351 - box.field_1322), Math.abs(at.field_1351 - box.field_1325),
                Math.abs(at.field_1350 - box.field_1321), Math.abs(at.field_1350 - box.field_1324)};
        boolean blow = incoming.method_1027() > 1.0e-8;
        class_243 best = null;
        double nearest = Double.MAX_VALUE;
        for (int i = 0; i < normals.length; i++) {
            if (blow && normals[i].method_1026(incoming) >= 0.0) {
                continue;
            }
            if (distances[i] < nearest) {
                nearest = distances[i];
                best = normals[i];
            }
        }
        return best != null ? best : facing(incoming, class_243.field_1353);
    }
}
