package dev.eann.atlasvfx;

import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;

/**
 * Effects out in the world, away from anything that draws itself: the shapes alive now, and the
 * motes thrown off them or left behind by anything else.
 *
 * <p>One for the whole client. It is ticked with the client, cleared with the world, and drawn
 * after the world's translucent geometry, through every {@link FxPass} in turn.</p>
 */
public final class FxWorld {

    /** Ceiling on its own motes alive at once, inside the shared {@link FxBudget}. */
    private static final int MAX_MOTES = 2400;
    private static final FxWorld INSTANCE = new FxWorld();

    /** One shape alive, with whose share of the effect it is made at; also its handle. */
    private static final class Live implements FxHandle {
        final FxShape shape;
        final FxDensity host;
        final FxLife life = new FxLife();
        boolean ended;

        Live(FxShape shape, FxDensity host) {
            this.shape = shape;
            this.host = host;
        }

        @Override
        public void release() {
            if (!ended) {
                life.release();
            }
        }

        @Override
        public void cancel() {
            if (!ended) {
                life.cancel();
            }
        }

        @Override
        public void flash() {
            if (!ended) {
                life.flash();
            }
        }

        @Override
        public boolean alive() {
            return !ended && !life.cancelled();
        }
    }

    private final List<Live> shapes = new ArrayList<>();
    private final MotePool motes = new MotePool(MAX_MOTES);
    private final Random random = new Random();

    private FxWorld() {
    }

    public static FxWorld get() {
        return INSTANCE;
    }

    // ---- shapes ----------------------------------------------------------------------------------------

    /**
     * Starts a shape, with what it throws off the moment it appears.
     *
     * @param host whose effect it is, for how much of it to make
     * @return a handle to let go of it, put it away or flash it
     */
    public FxHandle play(FxShape shape, FxDensity host) {
        Live live = new Live(shape, host);
        shapes.add(live);
        shape.open(this, host.effective());
        return live;
    }

    /**
     * Starts a shape on its own, without what it would throw off as it appears: for when
     * something else is already supplying the debris.
     *
     * @return a handle to let go of it, put it away or flash it
     */
    public FxHandle add(FxShape shape, FxDensity host) {
        Live live = new Live(shape, host);
        shapes.add(live);
        return live;
    }

    // ---- motes ---------------------------------------------------------------------------------------------

    public MotePool motes() {
        return motes;
    }

    public Random random() {
        return random;
    }

    /** Whether one more mote would be kept. */
    public boolean hasRoom() {
        return motes.hasRoom();
    }

    /** One mote, as it comes. */
    public void spawn(MoteRecipe recipe, class_243 at, class_243 velocity, float scale) {
        if (motes.hasRoom()) {
            motes.add(Mote.free(recipe, at, velocity, random, scale));
        }
    }

    /** Debris thrown out in every direction, far enough to reach about {@code reach} blocks. */
    public void spray(MoteRecipe recipe, class_243 at, float reach, int count) {
        // Thrown debris slows by a seventh a tick, so it travels about seven times its speed. A
        // recipe with a rate of its own is thrown for that rate instead.
        double speed = Math.max(0.05, recipe.profile().hasDrag() ? FxCone.launchSpeed(recipe, reach) : reach / 7.0);
        for (int i = 0; i < count && motes.hasRoom(); i++) {
            Vector3f v = unit(random);
            double s = speed * (0.45 + random.nextDouble() * 0.85);
            motes.add(Mote.free(recipe, at, new class_243(v.x * s, v.y * s * 0.8 + s * 0.2, v.z * s),
                    random, Math.min(2.0f, 0.8f + reach * 0.15f)));
        }
    }

    /**
     * Motes thrown one way: each along a direction within {@code halfAngle} degrees of
     * {@code axis}, hard enough to come to rest about {@code reach} blocks out - a little short
     * or long of it, so the front is ragged. A gust, a jet, a torrent; called every tick from a
     * shape that lasts, it is a stream. For a launch speed rather than a distance, see
     * {@link #jet(MoteRecipe, class_243, class_243, float, float, float, int)}.
     *
     * @param axis the way the cone faces; need not be of unit length
     */
    public void jet(MoteRecipe recipe, class_243 at, class_243 axis, float halfAngle, float reach, int count) {
        Vector3f middle = new Vector3f((float) axis.field_1352, (float) axis.field_1351, (float) axis.field_1350);
        double speed = FxCone.launchSpeed(recipe, reach);
        for (int i = 0; i < count && motes.hasRoom(); i++) {
            Vector3f v = FxCone.sample(middle, halfAngle, random);
            double s = speed * (0.55 + random.nextDouble() * 0.6);
            motes.add(Mote.free(recipe, at, new class_243(v.x * s, v.y * s, v.z * s), random, 1.0f));
        }
    }

    /**
     * Motes thrown one way, each along a direction within {@code halfAngle} degrees of
     * {@code axis}, at a speed picked evenly between {@code minSpeed} and {@code maxSpeed} blocks
     * per tick: for when how fast they fly matters more than where they land, the way sparks come
     * off a blade. Unlike {@link #jet(MoteRecipe, class_243, class_243, float, float, int) the jet by reach},
     * the range is the whole spread of speeds.
     *
     * @param axis the way the cone faces; need not be of unit length
     */
    public void jet(MoteRecipe recipe, class_243 at, class_243 axis, float halfAngle, float minSpeed, float maxSpeed,
                    int count) {
        checkSpeeds(minSpeed, maxSpeed);
        Vector3f middle = new Vector3f((float) axis.field_1352, (float) axis.field_1351, (float) axis.field_1350);
        for (int i = 0; i < count && motes.hasRoom(); i++) {
            Vector3f v = FxCone.sample(middle, halfAngle, random);
            double s = minSpeed + random.nextDouble() * (maxSpeed - minSpeed);
            motes.add(Mote.free(recipe, at, new class_243(v.x * s, v.y * s, v.z * s), random, 1.0f));
        }
    }

    /**
     * Motes thrown out in every direction at a speed picked evenly between {@code minSpeed} and
     * {@code maxSpeed} blocks per tick: chips off a hammer blow, sparks off a grinding wheel.
     */
    public void spray(MoteRecipe recipe, class_243 at, float minSpeed, float maxSpeed, int count) {
        checkSpeeds(minSpeed, maxSpeed);
        for (int i = 0; i < count && motes.hasRoom(); i++) {
            Vector3f v = unit(random);
            double s = minSpeed + random.nextDouble() * (maxSpeed - minSpeed);
            motes.add(Mote.free(recipe, at, new class_243(v.x * s, v.y * s, v.z * s), random, 1.0f));
        }
    }

    private static void checkSpeeds(float minSpeed, float maxSpeed) {
        if (!(minSpeed >= 0.0f && minSpeed <= maxSpeed)) {
            throw new IllegalArgumentException("speeds must run from 0 up: " + minSpeed + " to " + maxSpeed);
        }
    }

    /** Motes born anywhere within {@code spread} of a point, drifting gently. */
    public void scatter(MoteRecipe recipe, class_243 at, float spread, int count, double drift) {
        for (int i = 0; i < count && motes.hasRoom(); i++) {
            class_243 point = at.method_1031((random.nextDouble() - 0.5) * 2.0 * spread, (random.nextDouble() - 0.5) * spread,
                    (random.nextDouble() - 0.5) * 2.0 * spread);
            Vector3f v = unit(random);
            motes.add(Mote.free(recipe, point, new class_243(v.x * drift, Math.abs(v.y) * drift, v.z * drift),
                    random, 1.0f));
        }
    }

    // ---- ticking --------------------------------------------------------------------------------------------

    public void tick(class_310 client) {
        if (client.field_1687 == null) {
            clear();
            return;
        }
        advanceShapes();
        motes.tick();
    }

    /** Ticks every shape once: the cancelled go at once, the rest go when they say they are done. */
    void advanceShapes() {
        Iterator<Live> iterator = shapes.iterator();
        while (iterator.hasNext()) {
            Live live = iterator.next();
            if (live.life.cancelled()) {
                live.ended = true;
                iterator.remove();
                continue;
            }
            live.shape.tick(this, live.life, live.host.effective());
            live.life.advance();
            if (live.shape.done(live.life)) {
                live.ended = true;
                iterator.remove();
            }
        }
    }

    public void clear() {
        for (Live live : shapes) {
            live.ended = true;
        }
        shapes.clear();
        motes.clear();
    }

    // ---- drawing --------------------------------------------------------------------------------------------

    public void render(WorldRenderHook.Context context) {
        class_638 world = class_310.method_1551().field_1687;
        if (world == null || context.consumers() == null || context.matrices() == null
                || (shapes.isEmpty() && motes.isEmpty())) {
            return;
        }
        float tickDelta = context.tickDelta();
        FxPainter painter = FxPainter.world(context.consumers(), context.matrices().method_23760().method_23761(),
                new Quaternionf(context.camera().method_23767()), context.camera().method_19326());
        for (FxPass pass : FxPass.ordered()) {
            painter.begin(pass);
            for (Live live : shapes) {
                if (!live.life.cancelled()) {
                    live.shape.draw(painter, world, live.life, tickDelta);
                }
            }
            motes.draw(painter, world, false, tickDelta, -1);
        }
        painter.finish();
    }

    /** A direction picked evenly from all round. */
    public static Vector3f unit(Random random) {
        Vector3f v = new Vector3f();
        do {
            v.set(random.nextFloat() * 2.0f - 1.0f, random.nextFloat() * 2.0f - 1.0f, random.nextFloat() * 2.0f - 1.0f);
        } while (v.lengthSquared() < 1.0e-3f || v.lengthSquared() > 1.0f);
        return v.normalize();
    }
}
