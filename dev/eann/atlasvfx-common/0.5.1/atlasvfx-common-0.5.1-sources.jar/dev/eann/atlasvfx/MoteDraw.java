package dev.eann.atlasvfx;

/** How a mote is put down. */
public enum MoteDraw {
    /** Its picture facing the viewer, or a soft spot of light when it has none or is a glow. */
    SPRITE,
    /**
     * A soft line from where it is back along the way it came: a spark, a fleck of water. Long while
     * it flies, shortening as it slows. Always drawn as light, whatever its blend, and needs no picture.
     */
    STREAK
}
