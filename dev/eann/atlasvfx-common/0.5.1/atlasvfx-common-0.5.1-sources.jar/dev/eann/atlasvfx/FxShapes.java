package dev.eann.atlasvfx;

import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_638;

/**
 * The shapes any effect can be made of out in the world - pulses, novas, explosions, blasts,
 * beams and arcs - and the scattered kinds that are only motes: bursts, wisps, rain and smoke.
 *
 * <p>Each shape is a few lines of light in its style's colours that grow and fade over a handful
 * of ticks, plus motes thrown off it that then live on their own, so an impact looks like the
 * thing that caused it, only bigger. Start one with {@link FxWorld#play}, or with
 * {@link FxWorld#add} to leave out the debris it throws as it appears.</p>
 */
public final class FxShapes {

    /** Grey smoke or steam rising, belonging to nothing in particular. */
    public static final MoteRecipe SMOKE = new MoteRecipe(FxSprite.particleRun("big_smoke", 12), FxBlend.LIT,
            Motion.EMIT, 0x8A8A8A, 0.32f, 34, 1.0f, 0.25f, 0.04f, -0.006f, 0.04f, true, false);

    /** Turns a shape's own plane to lie flat on the ground. */
    public static final Quaternionf FLAT = new Quaternionf().rotationX((float) (Math.PI / 2.0));

    private FxShapes() {
    }

    // ---- making them ---------------------------------------------------------------------------------------

    /**
     * A blink of light and a ring running out across the view: a hit, a cue, a spark.
     *
     * @param tier 0 to 2, for how much it throws off
     */
    public static FxShape pulse(FxStyle style, class_243 at, float size, int tier) {
        return new Pulse(style, at, size, tier);
    }

    /** A ring of light running out across the ground, throwing up motes as it goes. */
    public static FxShape nova(FxStyle style, class_243 at, float size, int tier, long seed) {
        return new Nova(style, at, size, seed);
    }

    /** A bloom with a hot heart, blades of light, a shock ring and a spray of debris. */
    public static FxShape explosion(FxStyle style, class_243 at, float size, int tier, long seed) {
        return new Explosion(style, at, size, tier, seed);
    }

    /**
     * A shaft of light standing on a point, with a ring at its foot.
     *
     * @param falling whether it comes down onto the point from the sky rather than up out of it
     */
    public static FxShape blast(FxStyle style, class_243 at, float size, int tier, long seed, boolean falling) {
        return new Blast(style, at, size, falling);
    }

    /** A straight shaft of light between two points, sparkling along its length. */
    public static FxShape beam(FxStyle style, class_243 from, class_243 to, float width) {
        return new Beam(style, from, to, width);
    }

    /**
     * A jagged, flickering crack of light between two points.
     *
     * @param tier 0 to 2: how many forks branch off it
     */
    public static FxShape arc(FxStyle style, class_243 from, class_243 to, int tier, long seed) {
        return arc(style, from, to, tier, seed, Arc.DEFAULT_TICKS);
    }

    /**
     * As above, lasting {@code ticks}: it is redrawn on a new path every one of them, so a longer
     * arc is a longer flicker rather than a slower fade.
     */
    public static FxShape arc(FxStyle style, class_243 from, class_243 to, int tier, long seed, int ticks) {
        return new Arc(style, from, to, tier, seed, ticks);
    }

    /**
     * A blast one way: a flare at the mouth, streaks of light shooting out within the cone, and
     * the style's debris and accent thrown along it to about {@code reach} blocks. A gust, a
     * shockwave out of a staff, a spray of water - the aimed sibling of {@link #explosion}.
     *
     * @param axis      the way it faces; need not be of unit length
     * @param halfAngle half the cone's opening, in degrees
     * @param tier      0 to 2, for how much it throws
     */
    public static FxShape cone(FxStyle style, class_243 at, class_243 axis, float halfAngle, float reach, int tier,
                               long seed) {
        return new Cone(style, at, axis, halfAngle, reach, tier, seed);
    }

    // ---- motes alone ---------------------------------------------------------------------------------------

    /**
     * A small spray of the style's debris from a point, with a faint blink.
     *
     * @param count how much debris at a full share
     */
    public static void burst(FxWorld world, FxStyle style, class_243 at, float radius, int count, long seed,
                             FxDensity host) {
        float density = host.effective();
        world.add(pulse(style, at, Math.max(0.3f, radius * 0.6f), 0), host);
        world.spray(style.debris(), at, radius, Math.max(1, Math.round(count * density)));
        world.spray(style.accent(), at, radius, Math.max(1, Math.round(count * density * 0.4f)));
    }

    /** A few motes drifting off a point: something lingering, glowing, smouldering. */
    public static void wisp(FxWorld world, FxStyle style, class_243 at, float radius, int count, float density) {
        world.scatter(style.wisp(), at, radius, Math.max(1, Math.round(count * density)), 0.02);
    }

    /** Smoke or steam rising over a point. */
    public static void smoke(FxWorld world, class_243 at, float radius, int count, float density) {
        world.scatter(SMOKE, at, radius, Math.max(1, Math.round(count * density)), 0.03);
    }

    /** Things falling over a disc: the style's own falling mote, or its debris let drop. */
    public static void rain(FxWorld world, FxStyle style, class_243 at, float radius, int count, float density) {
        MoteRecipe recipe = (style.falling() != null ? style.falling() : style.debris().drifting(0.02f))
                .lasting(1.6f);
        Random random = world.random();
        int total = Math.max(1, Math.round(count * density));
        for (int i = 0; i < total && world.hasRoom(); i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = Math.sqrt(random.nextDouble()) * radius;
            class_243 point = at.method_1031(Math.cos(angle) * distance, random.nextDouble() * 0.5, Math.sin(angle) * distance);
            world.motes().add(Mote.free(recipe, point, new class_243(0.0, -0.15 - random.nextDouble() * 0.1, 0.0),
                    random, 1.3f));
        }
    }

    // ---- struck things ---------------------------------------------------------------------------------------

    /**
     * Something struck at {@code at}: the style's debris thrown on along the surface the way the
     * blow was going, leaning a little out of it; its accent thrown straight out of the surface in a
     * wider, slower, shorter spray; and a hard glint in its hot colour, with no halo. A blow straight
     * into the surface - a thrust - sprays everything back out of it.
     *
     * <p>Play it with {@link FxWorld#play} for the sprays; {@link FxWorld#add} draws only the glint.
     * In a {@link dev.eann.atlasvfx.cue.FxCueStyles#physical physical} style it is sparks off steel.</p>
     *
     * @param incoming the way the blow was travelling; need not be of unit length
     * @param normal   the way the struck surface faces, outward; need not be of unit length, and
     *                 when it has none the surface faces back against the blow
     * @param size     1 for a sword hit: scales how much is thrown, how fast, and the glint
     * @param tier     0 to 2, how much it throws off
     */
    public static FxShape impact(FxStyle style, class_243 at, class_243 incoming, class_243 normal, float size, int tier) {
        return impact(style, at, incoming, normal, size, tier, null);
    }

    /**
     * {@link #impact(FxStyle, class_243, class_243, class_243, float, int) Something struck} on a body that may
     * move: the glint rides along with it as it is knocked back.
     *
     * @param struck what was struck, for the glint to follow; null to leave it where it is
     */
    public static FxShape impact(FxStyle style, class_243 at, class_243 incoming, class_243 normal, float size, int tier,
                                 @Nullable class_1297 struck) {
        return new Impact(style, at, incoming, normal, size, tier, struck);
    }

    /**
     * A hard flash: full at once and gone within {@code ticks}, a short bright line along
     * {@code along} sliding on that way, and a fainter bar across it along {@code across}. No
     * coloured halo: a soft bloom is what makes a hit read as a spell going off.
     *
     * @param along  the way the line lies and slides; need not be of unit length
     * @param across the way the bar across it lies, the blade's own direction for a cut; need not be
     *               of unit length
     */
    public static FxShape glint(class_243 at, class_243 along, class_243 across, float size, int ticks, int rgb) {
        return glint(at, along, across, size, ticks, rgb, null);
    }

    /**
     * {@link #glint(class_243, class_243, class_243, float, int, int) A hard flash} riding along with a body as
     * it moves.
     *
     * @param follow what it rides on; null to leave it where it is
     */
    public static FxShape glint(class_243 at, class_243 along, class_243 across, float size, int ticks, int rgb,
                                @Nullable class_1297 follow) {
        return new Glint(at, along, across, size, ticks, rgb, follow);
    }

    // ---- the shapes ----------------------------------------------------------------------------------------

    private static final class Impact implements FxShape.Timed {
        /** How much the spray leans out of the struck surface rather than along it. */
        private static final double GLANCE = 0.45;
        private static final float DEBRIS_CONE = 22.0f;
        private static final float ACCENT_CONE = 65.0f;
        private static final int DEBRIS = 12;
        private static final int ACCENT = 5;
        private static final float GLINT_SIZE = 0.45f;
        private static final int GLINT_TICKS = 3;

        private final FxStyle style;
        private final class_243 at;
        private final class_243 incoming;
        private final class_243 normal;
        private final float size;
        private final int tier;
        private final Glint glint;

        Impact(FxStyle style, class_243 at, class_243 incoming, class_243 normal, float size, int tier, @Nullable class_1297 struck) {
            this.style = style;
            this.at = at;
            this.incoming = incoming;
            this.normal = FxSurface.facing(incoming, normal);
            this.size = Math.max(0.0f, size);
            this.tier = clampTier(tier);
            class_243 along = FxSurface.along(incoming, this.normal);
            this.glint = new Glint(at, along, this.normal.method_1036(along), GLINT_SIZE * this.size, GLINT_TICKS,
                    style.hot(), struck);
        }

        @Override
        public int ticks() {
            return GLINT_TICKS;
        }

        @Override
        public void open(FxWorld world, float density) {
            float more = (0.6f + 0.4f * tier) * size * density;
            // Heavier blows throw further, but not in proportion: twice the weight, two-fifths faster.
            float speed = (float) Math.sqrt(size);
            class_243 axis = FxSurface.glanceAxis(incoming, normal, GLANCE);
            world.jet(style.debris(), at, axis, DEBRIS_CONE, speed * FxMotes.SPARK_SPEED_MIN,
                    speed * FxMotes.SPARK_SPEED_MAX, Math.round(DEBRIS * more));
            world.jet(style.accent(), at, normal, ACCENT_CONE, speed * FxMotes.CHIP_SPEED_MIN,
                    speed * FxMotes.CHIP_SPEED_MAX, Math.round(ACCENT * more));
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            glint.draw(painter, world, life, tickDelta);
        }
    }

    private static final class Glint implements FxShape.Timed {
        private final class_243 at;
        private final class_243 along;
        private final class_243 across;
        private final float size;
        private final int ticks;
        private final int rgb;
        private final @Nullable class_1297 follow;
        /** Where it is from what it follows, so it rides along with it. */
        private final class_243 offset;

        Glint(class_243 at, class_243 along, class_243 across, float size, int ticks, int rgb, @Nullable class_1297 follow) {
            this.at = at;
            this.along = along.method_1027() > 1.0e-8 ? along.method_1029() : new class_243(1.0, 0.0, 0.0);
            this.across = across.method_1027() > 1.0e-8 ? across.method_1029()
                    : FxSurface.along(class_243.field_1353, this.along);
            this.size = size;
            this.ticks = Math.max(1, ticks);
            this.rgb = rgb;
            this.follow = follow;
            this.offset = follow != null ? at.method_1020(follow.method_19538()) : class_243.field_1353;
        }

        @Override
        public int ticks() {
            return ticks;
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            // Full at once and gone in a few frames, sliding on with the blow.
            float t = life.progress(tickDelta, ticks);
            float fade = (1.0f - t) * (1.0f - t) * (1.0f - t);
            class_243 base = follow != null && !follow.method_31481() ? follow.method_30950(tickDelta).method_1019(offset) : at;
            class_243 centre = base.method_1019(along.method_1021(size * 0.6f * t));
            painter.glow(centre, size * 0.12f, rgb, fade);
            float streak = size * 1.1f;
            painter.beam(centre.method_1020(along.method_1021(streak * 0.6f)), centre.method_1019(along.method_1021(streak * 0.4f)),
                    size * 0.07f * (1.0f - t), rgb, fade);
            float cross = size * 0.3f * (1.0f - t);
            painter.beam(centre.method_1020(across.method_1021(cross)), centre.method_1019(across.method_1021(cross)),
                    size * 0.04f * (1.0f - t), rgb, 0.6f * fade);
        }
    }

    private static final class Pulse implements FxShape.Timed {
        private final FxStyle style;
        private final class_243 at;
        private final float size;
        private final int tier;

        Pulse(FxStyle style, class_243 at, float size, int tier) {
            this.style = style;
            this.at = at;
            this.size = size;
            this.tier = clampTier(tier);
        }

        @Override
        public int ticks() {
            return 8;
        }

        @Override
        public void open(FxWorld world, float density) {
            float more = (1.0f + 0.35f * tier) * density;
            world.spray(style.debris(), at, size * 0.6f, Math.round(5 * more));
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            float grow = Math.min(1.0f, t / 0.2f);
            float r = size;
            painter.glow(at, r * 0.7f * (0.6f + 0.4f * grow), style.glow(), 0.75f * fade);
            painter.glow(at, r * 0.22f, style.hot(), fade);
            painter.ring(at, painter.facing(), r * (0.25f + 1.0f * t), r * 0.18f * (1.0f - t), style.hot(),
                    0.8f * (1.0f - t));
        }
    }

    private static final class Nova implements FxShape.Timed {
        private final FxStyle style;
        private final class_243 at;
        private final float size;
        private final long seed;

        Nova(FxStyle style, class_243 at, float size, long seed) {
            this.style = style;
            this.at = at;
            this.size = size;
            this.seed = seed;
        }

        @Override
        public int ticks() {
            return 14;
        }

        @Override
        public void tick(FxWorld world, FxLife life, float density) {
            float t = life.age() / (float) ticks();
            if (t > 0.6f) {
                return;
            }
            // Motes kicked up from the ring's edge as it passes.
            Random random = world.random();
            float ring = size * novaReach(t);
            int count = Math.round((3 + size * 2.5f) * density);
            for (int i = 0; i < count && world.hasRoom(); i++) {
                double angle = random.nextDouble() * Math.PI * 2.0;
                class_243 out = new class_243(Math.cos(angle), 0.0, Math.sin(angle));
                class_243 point = at.method_1019(out.method_1021(ring)).method_1031(0.0, 0.1, 0.0);
                world.motes().add(Mote.free(style.debris().drifting(-0.004f), point,
                        out.method_1021(0.04).method_1031(0.0, 0.05 + random.nextDouble() * 0.06, 0.0), random, 1.0f));
            }
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            float r = size;
            class_243 ground = at.method_1031(0.0, 0.08, 0.0);
            float reach = r * novaReach(t);
            float width = Math.max(0.1f, r * 0.12f) * (1.0f - 0.6f * t);
            painter.glow(ground, FLAT, reach * 1.05f, style.glow(), 0.2f * (1.0f - t));
            painter.ring(ground, FLAT, reach, width * 2.0f, style.glow(), 0.9f * (1.0f - t));
            painter.ring(ground, FLAT, reach * 0.85f, width * 0.7f, style.hot(), 0.75f * (1.0f - t));
            painter.glow(at.method_1031(0.0, 0.4, 0.0), r * 0.35f, style.hot(), 0.9f * fade);
            flare(painter, style, at.method_1031(0.0, 0.4, 0.0), r * 0.9f, t, seed);
        }
    }

    private static final class Explosion implements FxShape.Timed {
        private final FxStyle style;
        private final class_243 at;
        private final float size;
        private final int tier;
        private final long seed;

        Explosion(FxStyle style, class_243 at, float size, int tier, long seed) {
            this.style = style;
            this.at = at;
            this.size = size;
            this.tier = clampTier(tier);
            this.seed = seed;
        }

        @Override
        public int ticks() {
            return 11;
        }

        @Override
        public void open(FxWorld world, float density) {
            float r = size;
            float more = (1.0f + 0.35f * tier) * density;
            world.spray(style.debris(), at, r, Math.round((14 + r * 10) * more));
            world.spray(style.accent(), at, r, Math.round((6 + r * 5) * more));
            world.scatter(SMOKE, at, r * 0.5f, Math.round((2 + r * 2) * density), 0.04);
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            float grow = Math.min(1.0f, t / 0.2f);
            float r = size;
            if (style.rift()) {
                float open = (float) Math.sin(Math.PI * Math.min(1.0f, t * 1.3f));
                painter.rift(at, r * 0.45f * open, t * 0.5f);
                painter.ring(at, painter.facing(), r * 0.47f * open, r * 0.07f, style.glow(), 0.9f * open);
            }
            painter.glow(at, r * (0.5f + 0.7f * grow), style.glow(), 0.9f * fade);
            painter.glow(at, r * 0.3f * (1.0f - 0.5f * t), style.hot(), fade);
            flare(painter, style, at, r * 2.2f * (0.6f + 0.6f * t), t, seed);
            blades(painter, at, style, r, grow, t, fade, 8 + tier * 3, seed);
            painter.ring(at, painter.facing(), r * (0.3f + 1.5f * t), r * 0.2f * (1.0f - t), style.hot(),
                    0.8f * (1.0f - t));
            painter.ring(at, FLAT, r * (0.4f + 1.8f * t), r * 0.25f * (1.0f - t), style.glow(),
                    0.6f * (1.0f - t));
        }
    }

    private static final class Blast implements FxShape.Timed {
        private final FxStyle style;
        private final class_243 at;
        private final float size;
        private final boolean falling;

        Blast(FxStyle style, class_243 at, float size, boolean falling) {
            this.style = style;
            this.at = at;
            this.size = size;
            this.falling = falling;
        }

        @Override
        public int ticks() {
            return 16;
        }

        private float height() {
            return class_3532.method_15363(2.5f + size * 1.5f, 3.0f, 10.0f);
        }

        @Override
        public void tick(FxWorld world, FxLife life, float density) {
            float t = life.age() / (float) ticks();
            if (t > 0.7f) {
                return;
            }
            Random random = world.random();
            float height = height();
            int count = Math.round((2 + size * 1.5f) * density);
            for (int i = 0; i < count && world.hasRoom(); i++) {
                Vector3f v = FxWorld.unit(random);
                class_243 point = at.method_1031(v.x * size * 0.3, random.nextDouble() * height, v.z * size * 0.3);
                double rise = falling ? -0.18 : 0.14;
                world.motes().add(Mote.free(style.debris().drifting(0.0f), point,
                        new class_243(v.x * 0.02, rise * (0.6 + random.nextDouble() * 0.6), v.z * 0.02), random, 1.0f));
            }
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            float grow = Math.min(1.0f, t / 0.2f);
            float r = size;
            class_243 top = at.method_1031(0.0, height(), 0.0);
            // A falling shaft drops from the sky and lands; a rising one shoots up and thins.
            float reach = falling ? Math.min(1.0f, t * 3.0f) : grow;
            class_243 start = falling ? top : at;
            class_243 end = falling ? top.method_35590(at, reach) : at.method_35590(top, reach);
            float width = r * 0.55f * (1.0f - 0.7f * t);
            painter.beam(start, end, width, style.glow(), 0.85f * fade);
            painter.beam(start, end, width * 0.3f, style.hot(), fade);
            painter.glow(at.method_1031(0.0, 0.2, 0.0), r * 0.8f, style.glow(), 0.8f * fade);
            painter.glow(end, r * 0.45f, style.hot(), 0.8f * fade);
            painter.ring(at.method_1031(0.0, 0.08, 0.0), FLAT, r * (0.3f + 1.2f * t), r * 0.22f * (1.0f - t),
                    style.glow(), 0.8f * (1.0f - t));
        }
    }

    private static final class Beam implements FxShape.Timed {
        private final FxStyle style;
        private final class_243 from;
        private final class_243 to;
        private final float width;

        Beam(FxStyle style, class_243 from, class_243 to, float width) {
            this.style = style;
            this.from = from;
            this.to = to;
            this.width = width;
        }

        @Override
        public int ticks() {
            return 8;
        }

        @Override
        public void open(FxWorld world, float density) {
            sparkleAlong(world, style, from, to, density);
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            float w = Math.max(0.05f, width) * (1.0f - 0.3f * t);
            painter.beam(from, to, w, style.glow(), 0.85f * fade);
            painter.beam(from, to, w * 0.35f, style.hot(), fade);
            painter.glow(from, w * 1.5f, style.hot(), 0.8f * fade);
            painter.glow(to, w * 2.0f, style.glow(), 0.9f * fade);
        }
    }

    /**
     * A crack of light: a line pushed about at random between its ends, redrawn on another
     * random path every tick so it flickers, with forks off it for a stronger one.
     */
    private static final class Arc implements FxShape.Timed {
        static final int DEFAULT_TICKS = 5;

        private final FxStyle style;
        private final class_243 from;
        private final class_243 to;
        private final int tier;
        private final long seed;
        private final int ticks;

        Arc(FxStyle style, class_243 from, class_243 to, int tier, long seed, int ticks) {
            this.style = style;
            this.from = from;
            this.to = to;
            this.tier = clampTier(tier);
            this.seed = seed;
            this.ticks = Math.max(1, ticks);
        }

        @Override
        public int ticks() {
            return ticks;
        }

        @Override
        public void open(FxWorld world, float density) {
            sparkleAlong(world, style, from, to, density);
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            Random jag = new Random(seed + life.age() * 31L);
            List<class_243> path = jagged(from, to, jag, 0.18f + tier * 0.05f);
            strokes(painter, path, style, fade, 1.0f);
            for (int fork = 0; fork < tier; fork++) {
                class_243 start = path.get(1 + jag.nextInt(Math.max(1, path.size() - 2)));
                Vector3f v = FxWorld.unit(jag);
                double length = from.method_1022(to) * 0.3;
                class_243 end = start.method_1031(v.x * length, v.y * length, v.z * length);
                strokes(painter, jagged(start, end, jag, 0.12f), style, fade, 0.6f);
            }
            painter.glow(from, 0.25f, style.hot(), 0.8f * fade);
            painter.glow(to, 0.35f, style.glow(), 0.9f * fade);
        }

        private static void strokes(FxPainter painter, List<class_243> path, FxStyle style, float fade, float scale) {
            for (int i = 1; i < path.size(); i++) {
                painter.beam(path.get(i - 1), path.get(i), 0.16f * scale, style.glow(), 0.9f * fade);
                painter.beam(path.get(i - 1), path.get(i), 0.05f * scale, style.hot(), fade);
            }
        }

        private static List<class_243> jagged(class_243 from, class_243 to, Random jag, float jitter) {
            class_243 span = to.method_1020(from);
            int steps = Math.max(3, (int) Math.ceil(span.method_1033() * 2.5));
            List<class_243> path = new ArrayList<>(steps + 1);
            path.add(from);
            for (int i = 1; i < steps; i++) {
                Vector3f v = FxWorld.unit(jag);
                path.add(from.method_1019(span.method_1021(i / (double) steps)).method_1031(v.x * jitter, v.y * jitter, v.z * jitter));
            }
            path.add(to);
            return path;
        }
    }

    /**
     * A blast one way. Its streaks are picked once from its seed, so they hold still frame to
     * frame and shoot out along fixed lines; a shock ring rides the front of it, as wide as the
     * cone is at that distance.
     */
    private static final class Cone implements FxShape.Timed {
        private final FxStyle style;
        private final class_243 at;
        private final class_243 axis;
        private final float halfAngle;
        private final float reach;
        private final int tier;
        private final Vector3f[] streaks;
        private final float[] lengths;
        private final Quaternionf facing;

        Cone(FxStyle style, class_243 at, class_243 axis, float halfAngle, float reach, int tier, long seed) {
            this.style = style;
            this.at = at;
            class_243 unit = axis.method_1027() < 1.0e-8 ? new class_243(0.0, 1.0, 0.0) : axis.method_1029();
            this.axis = unit;
            this.halfAngle = class_3532.method_15363(halfAngle, 0.0f, 89.0f);
            this.reach = Math.max(0.1f, reach);
            this.tier = clampTier(tier);
            Random random = new Random(seed);
            Vector3f middle = new Vector3f((float) unit.field_1352, (float) unit.field_1351, (float) unit.field_1350);
            int count = 6 + this.tier * 3;
            this.streaks = new Vector3f[count];
            this.lengths = new float[count];
            for (int i = 0; i < count; i++) {
                streaks[i] = FxCone.sample(middle, this.halfAngle, random);
                lengths[i] = 0.6f + random.nextFloat() * 0.4f;
            }
            this.facing = new Quaternionf().rotationTo(0.0f, 0.0f, 1.0f, middle.x, middle.y, middle.z);
        }

        @Override
        public int ticks() {
            return 10;
        }

        @Override
        public void open(FxWorld world, float density) {
            float more = (1.0f + 0.6f * tier) * density;
            world.jet(style.debris(), at, axis, halfAngle, reach, Math.max(1, Math.round(10 * more)));
            world.jet(style.accent(), at, axis, halfAngle * 0.8f, reach * 0.8f, Math.max(1, Math.round(4 * more)));
        }

        @Override
        public void draw(FxPainter painter, @Nullable class_638 world, FxLife life, float tickDelta) {
            float t = life.progress(tickDelta, ticks());
            float fade = (1.0f - t) * (1.0f - t);
            // Out fast and easing off, the way a blast spends itself.
            float out = 1.0f - (1.0f - t) * (1.0f - t);
            float mouth = 0.3f + 0.1f * tier;
            painter.glow(at, mouth * (1.0f + 0.5f * out), style.glow(), 0.8f * fade);
            painter.glow(at, mouth * 0.4f, style.hot(), fade);

            float width = (0.1f + 0.04f * tier) * (1.0f - 0.6f * t);
            for (int i = 0; i < streaks.length; i++) {
                Vector3f d = streaks[i];
                float length = reach * lengths[i];
                float head = length * out;
                float tail = length * Math.max(0.0f, out - 0.4f);
                class_243 from = at.method_1031(d.x * tail, d.y * tail, d.z * tail);
                class_243 to = at.method_1031(d.x * head, d.y * head, d.z * head);
                painter.beam(from, to, width, style.glow(), 0.7f * fade);
                painter.beam(from, to, width * 0.35f, style.hot(), 0.9f * fade);
            }

            float distance = reach * out * 0.85f;
            float radius = distance * (float) Math.tan(Math.toRadians(halfAngle));
            class_243 front = at.method_1019(axis.method_1021(distance));
            painter.ring(front, facing, Math.max(0.1f, radius), Math.max(0.05f, radius * 0.18f) * (1.0f - t),
                    style.glow(), 0.6f * fade);
        }
    }

    // ---- pieces they share -------------------------------------------------------------------------------------

    /** Debris shaken loose along a line of light as it appears. */
    private static void sparkleAlong(FxWorld world, FxStyle style, class_243 from, class_243 to, float density) {
        Random random = world.random();
        class_243 span = to.method_1020(from);
        int count = Math.round((float) span.method_1033() * 3.0f * density) + 1;
        for (int i = 0; i < count && world.hasRoom(); i++) {
            class_243 point = from.method_1019(span.method_1021(random.nextDouble()));
            Vector3f v = FxWorld.unit(random);
            world.motes().add(Mote.free(style.debris(), point, new class_243(v.x, v.y, v.z).method_1021(0.03), random, 0.7f));
        }
    }

    /** Blades of light thrown out round a point, facing the viewer. */
    public static void blades(FxPainter painter, class_243 at, FxStyle style, float r, float grow, float t,
                              float fade, int count, long seed) {
        Quaternionf facing = painter.facing();
        Vector3f axisA = facing.transform(new Vector3f(1.0f, 0.0f, 0.0f));
        Vector3f axisB = facing.transform(new Vector3f(0.0f, 1.0f, 0.0f));
        Vector3f normal = facing.transform(new Vector3f(0.0f, 0.0f, 1.0f));
        Random blades = new Random(seed);
        float spin = blades.nextFloat() * class_3532.field_29846;
        for (int i = 0; i < count; i++) {
            float angle = spin + i * class_3532.field_29846 / count + (blades.nextFloat() - 0.5f) * 0.4f;
            Vector3f along = new Vector3f(axisA).mul((float) Math.cos(angle))
                    .add(new Vector3f(axisB).mul((float) Math.sin(angle)));
            Vector3f across = new Vector3f(normal).cross(along).normalize();
            float length = r * (0.9f + 0.8f * blades.nextFloat()) * grow * (1.0f - 0.3f * t);
            painter.petal(at, along, across, length, r * 0.18f, style.hot(), style.glow(), 0.9f * fade);
        }
    }

    /** The style's own picture going off once over a flash, if it has one. */
    public static void flare(FxPainter painter, FxStyle style, class_243 at, float size, float t, long seed) {
        if (style.flare() != null) {
            painter.sprite(FxBlend.EMISSIVE, style.flare(), t, (int) seed, true, at, size,
                    (seed % 628) / 100.0f, style.flareTint(), 0.9f * (1.0f - t), FxLight.FULL_BRIGHT, false);
        }
    }

    /** How far out a nova's ring has run: fast at first, easing as it reaches its edge. */
    public static float novaReach(float t) {
        float out = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
        return 0.08f + 0.92f * out;
    }

    private static int clampTier(int tier) {
        return class_3532.method_15340(tier, 0, 2);
    }
}
