package dev.eann.atlasvfx;

import org.jetbrains.annotations.Nullable;

/**
 * One kind of mote.
 *
 * @param rate     how many are given off per tick at full strength; for a burst, a count
 * @param size     across, in blocks; for a streak, how thick its line is
 * @param radius   for gathering and orbiting, how far out from the anchor; for the rest, how far
 *                 from where they start they may be born
 * @param speed    blocks per tick at birth; for orbiting, radians per tick round the anchor
 * @param gravity  blocks per tick per tick, downward; negative rises
 * @param flips    whether the picture flips through its frames over the mote's life, rather
 *                 than keeping one picked at birth. Without a size curve in its profile, a
 *                 flipping burst or emitted mote also swells as it goes, the way smoke does
 * @param crumb    whether to show only a corner of the picture, the way broken-block dust does,
 *                 so a whole block face reads as a fragment of one
 * @param profile  how it is drawn, how hard it slows, and how it changes over its life;
 *                 {@link MoteProfile#legacy()} for how motes always behaved
 */
public record MoteRecipe(@Nullable FxSprite sprite, FxBlend blend, Motion motion, int tint,
                         float size, int life, float rate, float radius, float speed,
                         float gravity, float spin, boolean flips, boolean crumb, MoteProfile profile) {

    public MoteRecipe {
        if (profile == null) {
            profile = MoteProfile.legacy();
        }
    }

    /** A mote that behaves as motes always have: {@link MoteProfile#legacy()}. */
    public MoteRecipe(@Nullable FxSprite sprite, FxBlend blend, Motion motion, int tint,
                      float size, int life, float rate, float radius, float speed,
                      float gravity, float spin, boolean flips, boolean crumb) {
        this(sprite, blend, motion, tint, size, life, rate, radius, speed, gravity, spin, flips, crumb,
                MoteProfile.legacy());
    }

    /** The same mote showing a broken-off corner of its picture. */
    public MoteRecipe asCrumb() {
        return new MoteRecipe(sprite, blend, motion, tint, size, life, rate, radius, speed,
                gravity, spin, flips, true, profile);
    }

    /**
     * The same mote drifting freely instead - slowing gently rather than hard, the way a thing
     * floats rather than flies - with its own pull up or down. A rate of slowing of its own, if
     * its profile has one, is kept.
     */
    public MoteRecipe drifting(float gravity) {
        return new MoteRecipe(sprite, blend, Motion.EMIT, tint, size, life, rate, radius, speed,
                gravity, spin, flips, crumb, profile);
    }

    /** The same mote in another colour, all its life: a colour gradient in its profile is dropped. */
    public MoteRecipe tinted(int rgb) {
        return new MoteRecipe(sprite, blend, motion, rgb, size, life, rate, radius, speed, gravity, spin,
                flips, crumb, profile.colour() == null ? profile : profile.colour(null));
    }

    /** The same mote drawn as a solid thing lit by the world, for smoke and dust. */
    public MoteRecipe lit() {
        return new MoteRecipe(sprite, FxBlend.LIT, motion, tint, size, life, rate, radius, speed,
                gravity, spin, flips, crumb, profile);
    }

    /** The same mote, living this many times as long. */
    public MoteRecipe lasting(float times) {
        return new MoteRecipe(sprite, blend, motion, tint, size, Math.max(2, Math.round(life * times)),
                rate, radius, speed, gravity, spin, flips, crumb, profile);
    }

    /** The same mote shaped by another profile. */
    public MoteRecipe profiled(MoteProfile newProfile) {
        return new MoteRecipe(sprite, blend, motion, tint, size, life, rate, radius, speed, gravity, spin,
                flips, crumb, newProfile);
    }

    /** The same mote drawn as a streak covering this many ticks of its motion; see {@link MoteProfile#streak}. */
    public MoteRecipe streaked(float ticks) {
        return profiled(profile.streak(ticks));
    }

    /** The same mote keeping this share of its speed each tick; see {@link MoteProfile#drag(float)}. */
    public MoteRecipe withDrag(float drag) {
        return profiled(profile.drag(drag));
    }

    /** The same mote sized over its life by this curve, as a share of its size at birth. */
    public MoteRecipe sizedOver(FxCurve curve) {
        return profiled(profile.size(curve));
    }

    /** The same mote faded over its life by this curve. */
    public MoteRecipe fadedOver(FxCurve curve) {
        return profiled(profile.alpha(curve));
    }

    /** The same mote coloured over its life by this gradient, in place of its tint. */
    public MoteRecipe colouredOver(FxGradient gradient) {
        return profiled(profile.colour(gradient));
    }

    /** The share of its speed a free mote of this kind keeps each tick. */
    public double drag() {
        return profile.hasDrag() ? profile.drag() : Mote.drag(motion);
    }
}
