package dev.eann.atlasvfx;

import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * How a kind of mote is drawn and how it moves beyond what {@link MoteRecipe} says outright: whether
 * it is a picture or a streak, how hard it slows, and how its size, opacity and colour run over its
 * life.
 *
 * <p>{@link #legacy()} is how every mote behaved before there were profiles - slowing by its
 * motion, sized and faded by its motion - and is what a recipe made without one gets. Each part
 * left unset keeps that behaviour, so a profile need only say what it changes.</p>
 *
 * <p>A class rather than a record so it can grow without changing how anyone already makes one.</p>
 */
public final class MoteProfile {

    /** How many ticks of its motion a streak covers when nothing says otherwise. */
    public static final float DEFAULT_STREAK_TICKS = 1.2f;

    private static final MoteProfile LEGACY = new MoteProfile(MoteDraw.SPRITE, Float.NaN, DEFAULT_STREAK_TICKS,
            0.0f, null, null, null);

    private final MoteDraw draw;
    private final float drag;
    private final float streakTicks;
    private final float tailFade;
    private final @Nullable FxCurve size;
    private final @Nullable FxCurve alpha;
    private final @Nullable FxGradient colour;

    private MoteProfile(MoteDraw draw, float drag, float streakTicks, float tailFade, @Nullable FxCurve size,
                        @Nullable FxCurve alpha, @Nullable FxGradient colour) {
        this.draw = draw;
        this.drag = drag;
        this.streakTicks = streakTicks;
        this.tailFade = tailFade;
        this.size = size;
        this.alpha = alpha;
        this.colour = colour;
    }

    /** Exactly how motes behaved before profiles: a picture or a glow, slowing and sized by their motion. */
    public static MoteProfile legacy() {
        return LEGACY;
    }

    public MoteDraw draw() {
        return draw;
    }

    /** The share of its speed a free mote keeps each tick; NaN to slow by its motion. */
    public float drag() {
        return drag;
    }

    /** Whether it slows at a rate of its own rather than by its motion. */
    public boolean hasDrag() {
        return !Float.isNaN(drag);
    }

    /** For a streak: how many ticks of its current motion the line covers. */
    public float streakTicks() {
        return streakTicks;
    }

    /** For a streak: how much dimmer the tail is than the head, 0 (as bright) to 1 (gone). */
    public float tailFade() {
        return tailFade;
    }

    /** Its size over its life, as a share of its size at birth; null to size it by its motion. */
    @Nullable
    public FxCurve size() {
        return size;
    }

    /** Its opacity over its life; null to fade it in and out by its motion. */
    @Nullable
    public FxCurve alpha() {
        return alpha;
    }

    /** Its colour over its life; null to keep its recipe's tint. */
    @Nullable
    public FxGradient colour() {
        return colour;
    }

    /** The same, put down another way. */
    public MoteProfile drawn(MoteDraw newDraw) {
        return new MoteProfile(Objects.requireNonNull(newDraw), drag, streakTicks, tailFade, size, alpha, colour);
    }

    /**
     * The same, drawn as a streak covering this many ticks of its motion.
     *
     * @param ticks how long the line is, in ticks of its current speed; above 0
     */
    public MoteProfile streak(float ticks) {
        return streak(ticks, tailFade);
    }

    /**
     * The same, drawn as a streak covering this many ticks of its motion, its tail dimmed.
     *
     * @param ticks    how long the line is, in ticks of its current speed; above 0
     * @param tailFade how much dimmer the tail is than the head, 0 to 1
     */
    public MoteProfile streak(float ticks, float tailFade) {
        if (!(ticks > 0.0f)) {
            throw new IllegalArgumentException("a streak covers more than 0 ticks: " + ticks);
        }
        if (!(tailFade >= 0.0f && tailFade <= 1.0f)) {
            throw new IllegalArgumentException("a tail fade runs from 0 to 1: " + tailFade);
        }
        return new MoteProfile(MoteDraw.STREAK, drag, ticks, tailFade, size, alpha, colour);
    }

    /**
     * The same, slowing at its own rate.
     *
     * @param newDrag the share of its speed kept each tick, above 0 and up to 1 (no slowing); NaN to
     *                slow by its motion again
     */
    public MoteProfile drag(float newDrag) {
        if (!Float.isNaN(newDrag) && !(newDrag > 0.0f && newDrag <= 1.0f)) {
            throw new IllegalArgumentException("drag is a share of speed kept, above 0 and up to 1: " + newDrag);
        }
        return new MoteProfile(draw, newDrag, streakTicks, tailFade, size, alpha, colour);
    }

    /** The same, sized over its life by this curve, as a share of its size at birth; null for by motion. */
    public MoteProfile size(@Nullable FxCurve newSize) {
        return new MoteProfile(draw, drag, streakTicks, tailFade, newSize, alpha, colour);
    }

    /** The same, faded over its life by this curve; null for by motion. */
    public MoteProfile alpha(@Nullable FxCurve newAlpha) {
        return new MoteProfile(draw, drag, streakTicks, tailFade, size, newAlpha, colour);
    }

    /** The same, coloured over its life by this gradient; null to keep the tint. */
    public MoteProfile colour(@Nullable FxGradient newColour) {
        return new MoteProfile(draw, drag, streakTicks, tailFade, size, alpha, newColour);
    }

    /**
     * Equal when every part is. Curves and gradients compare as themselves, not by their values, so
     * two profiles built from separately made but identical curves are not equal.
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MoteProfile that)) {
            return false;
        }
        return draw == that.draw && Float.compare(drag, that.drag) == 0
                && Float.compare(streakTicks, that.streakTicks) == 0 && Float.compare(tailFade, that.tailFade) == 0
                && Objects.equals(size, that.size) && Objects.equals(alpha, that.alpha)
                && Objects.equals(colour, that.colour);
    }

    @Override
    public int hashCode() {
        return Objects.hash(draw, drag, streakTicks, tailFade, size, alpha, colour);
    }

    @Override
    public String toString() {
        return "MoteProfile[draw=" + draw + ", drag=" + drag + ", streakTicks=" + streakTicks + ", tailFade="
                + tailFade + ", size=" + size + ", alpha=" + alpha + ", colour=" + colour + "]";
    }
}
