package dev.eann.atlasvfx;

/**
 * Ready-made motes for things struck rather than cast: sparks, chips and dust. Generic by what they
 * are, not by what made them, and drawn without glitter, without swelling and without lingering, so
 * they read as matter flying rather than magic going off.
 *
 * <p>Sparks and chips are streaks: give them a launch speed with
 * {@link FxWorld#jet(MoteRecipe, net.minecraft.class_243, net.minecraft.class_243, float, float, float, int)}
 * so they visibly fly.</p>
 */
public final class FxMotes {

    /** Struck metal: white-hot as it leaves, cooling to orange. */
    public static final int SPARK_HOT = 0xFFF2D0;
    public static final int SPARK_COOL = 0xFF8A2A;
    /** Grey-brown, the colour of most things knocked loose. */
    public static final int DUST = 0x8A8178;

    /** How fast sparks are meant to be thrown, blocks per tick, slowest to fastest. */
    public static final float SPARK_SPEED_MIN = 0.32f;
    public static final float SPARK_SPEED_MAX = 0.6f;
    /** How fast chips are meant to be thrown: slower, shorter. */
    public static final float CHIP_SPEED_MIN = 0.15f;
    public static final float CHIP_SPEED_MAX = 0.3f;

    private static final float STREAK_WIDTH = 0.03f;
    private static final float SPARK_DRAG = 0.88f;
    private static final float SPARK_GRAVITY = 0.04f;
    /** Thinning to half by the end of its life. */
    private static final FxCurve THINNING = FxCurve.LINEAR.reversed().between(0.5f, 1.0f);
    private static final FxCurve BURNING_OUT = FxCurve.holdThenFade(0.6f);

    private FxMotes() {
    }

    /** Sparks white-hot cooling to orange, the colour of struck steel. */
    public static MoteRecipe sparks() {
        return sparks(SPARK_HOT, SPARK_COOL);
    }

    /**
     * Thrown sparks: each a streak back along its motion, braking hard and falling, cooling from
     * {@code hot} to {@code cool} as it burns out over 4 to 6 ticks.
     */
    public static MoteRecipe sparks(int hot, int cool) {
        return streak(hot, cool, 5);
    }

    /** Chips in struck steel's colours. */
    public static MoteRecipe chips() {
        return chips(SPARK_HOT, SPARK_COOL);
    }

    /**
     * Chips off a struck surface: sparks that live only 2 to 4 ticks, for a short, wide spray
     * straight out of what was hit.
     */
    public static MoteRecipe chips(int hot, int cool) {
        return streak(hot, cool, 3);
    }

    /**
     * Dust knocked loose: small, lit by the world, drifting and settling over about half a second,
     * thinning rather than swelling.
     */
    public static MoteRecipe dust(int rgb) {
        MoteRecipe recipe = new MoteRecipe(FxSprite.particleRun("generic", 8), FxBlend.LIT, Motion.EMIT, rgb,
                0.12f, 12, 1.0f, 0.08f, 0.03f, 0.003f, 0.05f, false, false);
        return recipe.withDrag(0.9f).sizedOver(FxCurve.LINEAR.reversed().between(0.6f, 1.0f))
                .fadedOver(FxCurve.holdThenFade(0.3f));
    }

    /**
     * Flecks of a material: lit broken-off corners of a picture - stone, wood, ice - thrown and
     * falling. The caller names the picture, typically a block's.
     */
    public static MoteRecipe flecks(FxSprite sprite) {
        return new MoteRecipe(sprite, FxBlend.LIT, Motion.BURST, FxColor.WHITE, 0.1f, 14, 1.0f, 0.05f, 0.2f,
                0.04f, 0.3f, false, true).sizedOver(FxCurve.ONE).fadedOver(FxCurve.holdThenFade(0.7f));
    }

    private static MoteRecipe streak(int hot, int cool, int life) {
        MoteRecipe recipe = new MoteRecipe(null, FxBlend.GLOW, Motion.BURST, hot, STREAK_WIDTH, life, 1.0f, 0.0f,
                SPARK_SPEED_MAX, SPARK_GRAVITY, 0.0f, false, false);
        // Cools in the first seven-tenths of its life and burns out at the last colour.
        FxGradient cooling = FxGradient.at(new float[] {0.0f, 1.0f / 1.4f}, new int[] {hot, cool});
        return recipe.profiled(recipe.profile().streak(MoteProfile.DEFAULT_STREAK_TICKS).drag(SPARK_DRAG)
                .size(THINNING).alpha(BURNING_OUT).colour(cooling));
    }
}
