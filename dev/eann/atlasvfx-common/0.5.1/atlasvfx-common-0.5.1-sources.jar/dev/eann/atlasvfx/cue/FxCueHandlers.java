package dev.eann.atlasvfx.cue;

import dev.architectury.networking.NetworkManager;
import dev.eann.atlasvfx.FxDensity;
import dev.eann.atlasvfx.FxShapes;
import dev.eann.atlasvfx.FxStyle;
import dev.eann.atlasvfx.FxSurface;
import dev.eann.atlasvfx.FxWorld;
import dev.eann.atlasvfx.telegraph.Telegraph;
import dev.eann.atlasvfx.telegraph.TelegraphStyle;
import dev.eann.atlasvfx.trail.ArcSweep;
import dev.eann.atlasvfx.trail.SweepFrame;
import dev.eann.atlasvfx.trail.SweepFrameSource;
import dev.eann.atlasvfx.trail.Trail;
import dev.eann.atlasvfx.trail.TrailStyles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_638;

/**
 * The client's side of cues: turns the server's cue and telegraph packets into shapes. Client only.
 *
 * <p>The built-in cues in {@link FxCues} are registered here already. A mod with a bespoke look
 * registers its own name and handler, and its server sends that name with {@link FxEmitter} like
 * any built-in one - or registers over a built-in name to draw it its own way.</p>
 */
public final class FxCueHandlers {

    private static final Logger LOGGER = LoggerFactory.getLogger("atlasvfx");

    /** Draws one cue. Runs on the client thread. */
    @FunctionalInterface
    public interface Handler {
        void play(FxWorld world, FxCueArgs args);
    }

    /**
     * How much of a cue to make. Cues arrive from a server, not from one mod's own code, so they are
     * made at the game's particle setting alone.
     */
    public static final FxDensity DENSITY = FxDensity.FULL;

    /**
     * Copy-on-write: mods register during start-up, which on NeoForge runs on parallel threads,
     * so a plain map could lose a registration outright. Writers take the class lock and publish a
     * fresh map; a draw reads it with one volatile load and no locking.
     */
    private static volatile Map<class_2960, Handler> handlers = Map.of();
    private static boolean started;

    static {
        register(FxCues.PULSE, (world, a) -> world.play(FxShapes.pulse(style(a), a.at(), a.size(), a.tier()), DENSITY));
        register(FxCues.NOVA, (world, a) ->
                world.play(FxShapes.nova(style(a), a.at(), a.size(), a.tier(), a.seed()), DENSITY));
        register(FxCues.EXPLOSION, (world, a) ->
                world.play(FxShapes.explosion(style(a), a.at(), a.size(), a.tier(), a.seed()), DENSITY));
        register(FxCues.BLAST, (world, a) ->
                world.play(FxShapes.blast(style(a), a.at(), a.size(), a.tier(), a.seed(), false), DENSITY));
        register(FxCues.BLAST_FALLING, (world, a) ->
                world.play(FxShapes.blast(style(a), a.at(), a.size(), a.tier(), a.seed(), true), DENSITY));
        register(FxCues.BEAM, (world, a) -> world.play(FxShapes.beam(style(a), a.at(), a.to(), a.size()), DENSITY));
        register(FxCues.ARC, (world, a) ->
                world.play(FxShapes.arc(style(a), a.at(), a.to(), a.tier(), a.seed()), DENSITY));
        register(FxCues.CONE, (world, a) ->
                world.play(FxShapes.cone(style(a), a.at(), a.to(), a.angle(), a.size(), a.tier(), a.seed()), DENSITY));
        register(FxCues.BURST, (world, a) -> FxShapes.burst(world, style(a), a.at(), a.size(), 12, a.seed(), DENSITY));
        register(FxCues.WISP, (world, a) -> FxShapes.wisp(world, style(a), a.at(), a.size(), 16, DENSITY.effective()));
        register(FxCues.SMOKE, (world, a) -> FxShapes.smoke(world, a.at(), a.size(), 24, DENSITY.effective()));
        register(FxCues.RAIN, (world, a) -> FxShapes.rain(world, style(a), a.at(), a.size(), 16, DENSITY.effective()));
        register(FxCues.SLASH, (world, a) -> world.play(Trail.slash(
                SweepFrameSource.fixed(SweepFrame.of(a.at(), yawOf(a.to()), 0.0f)), a.size(), a.angle(),
                a.tier() == 1, ArcSweep.Plane.HORIZONTAL, 5, 6, TrailStyles.slash(style(a).glow()), a.seed()),
                DENSITY));
        register(FxCues.IMPACT, FxCueHandlers::impact);
    }

    private FxCueHandlers() {
    }

    /** Names a cue and how to draw it, replacing whatever drew that name before. */
    public static synchronized void register(class_2960 cue, Handler handler) {
        Map<class_2960, Handler> next = new HashMap<>(handlers);
        next.put(cue, handler);
        handlers = Map.copyOf(next);
    }

    /**
     * Declares the payloads and their receivers. Called once by the library's own client start,
     * during mod construction, which is when a loader accepts them.
     */
    public static void registerReceivers() {
        if (started) {
            return;
        }
        started = true;
        NetworkManager.registerReceiver(NetworkManager.Side.S2C, FxCuePayload.ID, FxCuePayload.CODEC,
                (payload, context) -> context.queue(() -> play(payload.cue(), payload.args())));
        NetworkManager.registerReceiver(NetworkManager.Side.S2C, TelegraphPayload.ID, TelegraphPayload.CODEC,
                (payload, context) -> context.queue(() -> telegraph(payload)));
    }

    /**
     * Draws a cue as if the server had sent it: for a client effect that wants a built-in look, or a
     * single-player shortcut.
     *
     * @return whether anything drew that name
     */
    public static boolean play(class_2960 cue, FxCueArgs args) {
        Handler handler = handlers.get(cue);
        if (handler == null) {
            LOGGER.debug("[atlasvfx] no client handler for cue {}", cue);
            return false;
        }
        handler.play(FxWorld.get(), args);
        return true;
    }

    /** Lays a telegraph as if the server had sent it. */
    public static void telegraph(TelegraphPayload payload) {
        TelegraphStyle style = payload.colour() != 0
                ? FxCueStyles.telegraph(payload.colour())
                : FxCueStyles.telegraph(payload.style());
        FxWorld.get().play(Telegraph.fixed(payload.area(), payload.timing(), style), DENSITY);
    }

    /** An impact cue: finds the struck surface here, from the body it follows or the block in the way. */
    private static void impact(FxWorld world, FxCueArgs args) {
        class_310 client = class_310.method_1551();
        class_638 level = client.field_1687;
        class_1297 struck = level != null && args.entityId() >= 0 ? level.method_8469(args.entityId()) : null;
        class_243 incoming = args.to();
        class_243 normal;
        if (struck != null) {
            normal = FxSurface.boxNormal(struck.method_5829(), args.at(), incoming);
        } else {
            normal = blockNormal(client, args.at(), incoming);
        }
        world.play(FxShapes.impact(style(args), args.at(), incoming, normal, args.size(), args.tier(), struck),
                DENSITY);
    }

    /** The face of the block a blow travelling {@code incoming} ran into at {@code at}; none if there is none. */
    private static class_243 blockNormal(class_310 client, class_243 at, class_243 incoming) {
        if (client.field_1687 == null || client.field_1724 == null || incoming.method_1027() < 1.0e-8) {
            return class_243.field_1353;
        }
        class_243 step = incoming.method_1029().method_1021(0.5);
        class_3965 hit = client.field_1687.method_17742(new class_3959(at.method_1020(step), at.method_1019(step),
                class_3959.class_3960.field_17558, class_3959.class_242.field_1348, client.field_1724));
        if (hit.method_17783() != class_239.class_240.field_1332) {
            return class_243.field_1353;
        }
        return class_243.method_24954(hit.method_17780().method_10163());
    }

    private static FxStyle style(FxCueArgs args) {
        return FxCueStyles.style(args.style());
    }

    /** The yaw a direction faces, as the game turns: 0 is south. */
    static float yawOf(class_243 direction) {
        return (float) Math.toDegrees(Math.atan2(-direction.field_1352, direction.field_1350));
    }
}
